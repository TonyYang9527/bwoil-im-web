import {observable, action, autorun} from 'mobx';

import globalStore from './GlobalStore';
import messageStore from './MessageStore';
import conversationStore from './ConversationStore';
import stepStore from './StepStore';
import profileStore from './ProfileStore';
import addContactStore from './AddContactStore';
import partnerStore from './PartnerStore';
import {sessions} from '../mock/Data';
const state = observable({
    sessions: observable.map(),
    selected: {},
    copy: {},
});

const actions = {
    init: action((sessions) => {
        /**TODO: please call init api**/
        sessions.forEach((item) => {
            item.className = "conversation";
            item.modalVisible = false;
            state.sessions.set(item.id, item);
        });
    }),

    select: action((id) => {
        if (state.sessions.has(id)) {
            state.selected = state.sessions.get(id);
            state.selected.unread = 0;
            actions.changeStyle(String(id));

            /**TODO: please call other api**/
            messageStore.actions.init(id);
            conversationStore.actions.init(id);
            stepStore.actions.init(id);
            profileStore.actions.init(id);

        }
        globalStore.actions.restoreTab();
    }),

    add: action((contact) => {
        var id  =Math.floor(Math.random()*100000)+1 ;
       console.log("add :",contact) ;
       console.log("add id :",id) ;
        /**TODO: please call add api**/
        let newSession ={
            id :  id , 
            name:  contact.name,
            status: contact.status,
            unread : 0,
            time : "02:49",
            message : "",
            icon :  "",
            partners :[contact.id],
            className: "conversation",
            modalVisible :false 
        } ;
        state.sessions.set(id, newSession);
        actions.changeStyle(String(id));
        globalStore.actions.restoreTab();
    }),

    onOk: action((opt, covsId) => {
        if (opt === "1") { //delete conversation
            state.sessions.get(covsId).modalVisible = false;
            state.sessions.delete(covsId);
            /**TODO: please call delete api**/
        } else if (opt === "2") { //rename conversation
            state.sessions.get(covsId);
            state.sessions.get(covsId).modalVisible = false;
            ;
            /**TODO: please call rename api**/
        } else if (opt === "3") { //exit  conversation
            state.sessions.get(covsId).modalVisible = false;
            state.sessions.delete(covsId);
            /**TODO: please call exit api**/
        }
    }),

    onCancel: action((opt, id) => {
        if (opt === "2") {
            state.sessions.get(id).name = state.copy.name;
            state.sessions.get(id).modalVisible = false;
        } else if (opt === "1" || opt === "3") {
            state.sessions.get(id).modalVisible = false;
        } else {
            //  do  nothing
        }
    }),

    dropdown: action((key, session) => {
        session.modalVisible = true;
        session.opt = key;
        state.copy = {id: session.id, opt: key, name: session.name};
    }),

    addContact: action((id, preAdd) => {
        /**TODO: please call invite  api**/
        let temp = preAdd.values();
        state.selected.partners = state.selected.partners.concat(temp);
        addContactStore.actions.closeModal();
    }),

    changeStyle: action((id) => {
        state.sessions.forEach((value, key, map) => {
            if (key === id) {
                value.className = 'conversation conversation-focused';
            } else {
                value.className = 'conversation';
            }
        });
    }),
};

autorun(() => {
    if (!state.sessions.size) {
        actions.init(sessions);
    }
    if (state.selected.partners) {
        partnerStore.actions.closeModal();
    }
});

export default {state, actions};