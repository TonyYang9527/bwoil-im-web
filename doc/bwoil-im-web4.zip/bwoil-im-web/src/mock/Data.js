export const messages = [
    {
        id: '10002',
        avatar: require("../assets/master.jpg"),
        type: "text",
        message: "I miss you dear,call me please. I leave message  to  you.",
        status: "sent",
        time: "02:49",
        sender: 'King',
        fromUser: false
    },
    {
        id: '10003',
        avatar: require("../assets/master.jpg"),
        type: "image",
        message: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        status: "received",
        time: "02:49",
        sender: 'Tony',
        fromUser: true
    },
    {
        id: '10004',
        avatar: require("../assets/master.jpg"),
        type: "sub",
        message: "Onsub",
        status: "read",
        time: "02:49",
        sender: 'Jack',
        fromUser: false
    },
    {
        id: '10005',
        avatar: require("../assets/master.jpg"),
        type: "sub",
        message: "Offer",
        expiry: "03:49",
        status: "read",
        time: "02:49",
        sender: 'Mike',
        fromUser: true
    }, {
        id: '10006',
        avatar: require("../assets/master.jpg"),
        type: "text",
        message: "I miss you dear,call me please. i leave message  to  you",
        status: "sent",
        time: "02:49",
        sender: 'Mike',
        fromUser: true
    },
    {
        id: '10007',
        avatar: require("../assets/master.jpg"),
        type: "image",
        message: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        status: "received",
        time: "02:49",
        sender: 'williness',
        fromUser: false
    }
];

export const profiles = {
    vessel: 'BRIGHTOIL GLORY',
    sector: 'Oil Tanker',
    openDate: '01/01/2018',
    openPorts: 'Singapore,China, Indonesia,India',
    cargoVessel: 'PIG IRON,5000MT',
    laycanDate: '01-05 Jan 2018',
    voyage: 'Singapore>Shanghai',
    loadRate: '1500/1500',
    addressComission: '3.75%',
    freight: 'SGD:15/MTS'
};

export const cargo = {
    cargo: 'PIG IRON,5000MT',
    laycanDate: '01-05 Jan 2018',
    voyage: 'Singapore>Shanghai',
    loadRate: '1500/1500',
    addressComission: '3.75%',
    freight: 'SGD:15/MTS'
};

export const vessel = {
    vessel: 'BRIGHTOIL GLORY',
    sector: 'Oil Tanker',
    openDate: '01/01/2018',
    openPorts: 'Singapore,China, Indonesia,India'
};


export const step = {
    current: 1,
    status: 'finish'
};

export const sessions = [
    {
        id: 101,
        name: 'Jim King,Yang Sun,Qiaomin Jin',
        status: "success",  // 0:offline 1:online
        image: require("../assets/master.jpg"),
        unread: 10,
        time: "02:49",
        message: "I miss you dear,call me please. I leave message  to  you.",
        partners: [200, 201, 202, 203, 204, 205, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115]
    },
    {
        id: 102,
        name: 'Jake Li',
        status: "default", // 0:offline 1:online
        image: require("../assets/master.jpg"),
        unread: 10,
        time: "02:49",
        message: "Please  comfirm our contact .",
        partners: [200, 202, 203]
    },

    {
        id: 103,
        name: 'Tony.yang',
        status: "error", // 0:offline 1:online
        image: require("../assets/master.jpg"),
        unread: 10,
        time: "02:49",
        message: "Please  comfirm our contact .",
        partners: [202, 203]
    }
];

export const contacts = [
    {
        id: 200,
        name: "Jim King",
        image: require("../assets/master.jpg"),
        status: "error"
    },
    {
        id: 201,
        name: "Yang Sun",
        image: require("../assets/master.jpg"),
        status: "default"
    },
    {
        id: 202,
        name: "QiaoMin Jin",
        image: require("../assets/master.jpg"),
        status: "error"
    },
    {
        id: 203,
        name: "Jake Li",
        image: require("../assets/master.jpg"),
        status: "default"
    },
    {
        id: 204,
        name: "Standly McNair",
        image: require("../assets/master.jpg"),
        status: "error"
    },
    {
        id: 205,
        name: "Charles Smith",
        image: require("../assets/master.jpg"),
        status: "error"
    },
    {
        id: 106,
        name: "Kelli Ortiz",
        image: require("../assets/master.jpg"),
        status: "error"
    },
    {
        id: 107,
        name: "Tony Yang",
        image: require("../assets/master.jpg"),
        status: "success"
    },
    {
        id: 108,
        name: "Lebron James",
        image: require("../assets/master.jpg"),
        status: "success"
    },
    {
        id: 109,
        name: "Embid",
        image: require("../assets/master.jpg"),
        status: "success"
    },
    {
        id: 110,
        name: "Durant",
        image: require("../assets/master.jpg") ,
        status: "error"
    },
    {
        id: 111,
        name: "Howard",
        image: require("../assets/master.jpg"),
        status: "error"
    },
    {
        id: 112,
        name: "Wade",
        image: require("../assets/master.jpg"),
        status: "error"
    },
    {
        id: 113,
        name: "Anthony",
        image: require("../assets/master.jpg"),
        status: "error"
    },
    {
        id: 114,
        name: "George",
        image: require("../assets/master.jpg"),
        status: "error"
    },
    {
        id: 115,
        name: "WhiteSide",
        image: require("../assets/master.jpg"),
        status: "success"
    }
];