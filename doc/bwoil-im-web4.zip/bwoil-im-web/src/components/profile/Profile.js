import React from 'react';
import {observer} from "mobx-react";
import profileStore from '../../stores/ProfileStore';
import './Profile.less';

const Vessel = observer((props)=>{

    if(!props.vessel){
        return  null; 
    }

    return (
       <div>
        <span>Vessel Info</span>
        <div>
            <span>Vessel</span>
            <span>{props.vessel?props.vessel.vessel:"--"}</span>
        </div>
        <div>
            <span>Sector</span>
            <span>{props.vessel?props.vessel.sector:"--"}</span>
        </div>
        <div>
            <span>Open Date</span>
            <span>{props.vessel?props.vessel.openDate:"--"}</span>
        </div>
        <div>
            <span>Open Ports</span>
            <span>{props.vessel?props.vessel.openPorts:"--"}</span>
        </div>
    </div>
    );
  });

  const Cargo = observer((props)=>{

    if(!props.cargo){
        return  null; 
    }

    return (
        <div>
        <span>Cargo Info</span>
        <div>
            <span>Cargo</span>
            <span >{props.cargo?props.cargo.cargo:"--"}</span>
        </div>
        <div>
            <span>Laycan date</span>
            <span>{props.cargo?props.cargo.laycanDate:"--"}</span>
        </div>
        <div>
            <span>Voyage</span>
            <span>{props.cargo?props.cargo.voyage:"--"}</span>
        </div>
        <div>
            <span>Loading/Discharging Rate</span>
            <span>{props.cargo?props.cargo.loadRate:"--"}</span>
        </div>
        <div>
            <span>Address Comission</span>
            <span>{props.cargo?props.cargo.addressComission:"--"}</span>
        </div>
        <div>
            <span >Freight</span>
            <span >{props.cargo?props.cargo.freight:"--"}</span>
        </div>
    </div>
    );

  });

const Profile = observer(() => {
        return (
             <div className='profile'>
              <Cargo  cargo ={profileStore.state.cargo} />
              <Vessel vessel={profileStore.state.vessel} />
            </div>
        )
    }
);
export default Profile;