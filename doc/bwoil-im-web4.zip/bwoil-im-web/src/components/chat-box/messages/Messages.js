import React from 'react';
import { observer } from "mobx-react";
import BwoilScrollbars from "../../scrollbars/Scrollbars";
import Message from '../../message/index' ;
import './messages.less';

const Messages = observer((props) => {
    return (
        <div style={{ width: 480, height: 476 }}>
            <BwoilScrollbars>
                {props.messages.map((item, index) => <Message message={item} key={index} />)}
            </BwoilScrollbars>
        </div>
    );
});
export default Messages;