import React from 'react';
import {observer} from 'mobx-react';
import {Avatar,Badge} from 'antd';
import randomColor from 'random-color';
const UserAvatar =observer((props) => {
    return (
        <Badge dot  status={props.contact.status}  offset={[29,-2]}>
            <Avatar style={{backgroundColor: randomColor().hexString()}} icon="user" />
        </Badge>
    );
}) ;
export default UserAvatar;