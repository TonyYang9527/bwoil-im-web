import React from 'react';
import { observer } from "mobx-react";
import './text.less';


const TextMessage = observer((props) => {
    return (
            <div className="plain">
                <span className="js_message_plain ng-binding" >{props.message.message}</span>
            </div>
    );
});

  /******Text******/
//bubble bubble_primary right
//bubble bubble_default left
  /******Text******/
const TextBubble = observer((props) => {
    return (
        <div className={props.className}>
            <div className="bubble_cont">
                 <TextMessage message={props.message} />
            </div> 
        </div>
    );
});

const GroupMessage = observer((props) => {
    return (
        <div className="msgcontent">
            <h4 className="nickname">{props.message.sender}</h4>
            <TextBubble message={props.message} className={props.className} />
        </div>
    );
});

const UserMessage = observer((props) => {
    return (
        <div className="msgcontent">
            <TextBubble message={props.message} className={props.className} />
        </div>
    );
});

const MessageTimde = observer((props) => {
    return (
        <div className="message_system">
            <div className="sendTime">{props.message.time}</div>
        </div>
    );
});

const UserAvatar = observer((props) => {
    return (<img className="avatar" src="https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png" />);
});

const BubbleMessage = observer((props) => {
    const ume = props.message.fromUser ? 'message me' : 'message you';
    const bubble = props.message.fromUser ? 'bubble bubble_primary right' : 'bubble bubble_default left';
    return (
        <div className={ume} >
            <MessageTimde message={props.message} />
              <UserAvatar message={props.message}/>
              <GroupMessage message={props.message} className={bubble} />
        </div>
    );
});

const BubbleMessage2 = observer((props) => {
    const ume = props.message.fromUser ? 'message me' : 'message you';
    const bubble = props.message.fromUser ? 'bubble bubble_primary right' : 'bubble bubble_default left';
    return (
        <div className={ume} >
            {props.message.fromUser ? null:<UserAvatar message={props.message} />}
             <UserMessage message={props.message} className={bubble} />
            {props.message.fromUser ? <UserAvatar message={props.message} /> : null}
        </div>
    );
});
export default BubbleMessage2;