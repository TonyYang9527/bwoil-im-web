import React from 'react';
import {observer} from "mobx-react";
import {Modal,Icon} from 'antd';
import './ImageMsg.less';

const PreImage = observer((props) => {
     const onCancel = (e) => {
        e.stopPropagation();
     };
    return (
        <Modal visible={true} footer={null} onCancel={onCancel}>
           <img alt="example" style={{width: '100%'}} src={props.message.message} />  
       </Modal>
    );
});

const ImageMsg = observer((props) => {
        const preView =(e)=>{
             console.log("preView onCilck ") ;
             alert("preView") ;
             e.stopPropagation();
        };
       const download = (e) => {
          console.log("download onCilck ");
          alert("download");
          e.stopPropagation();
         };
        return (
        <div className="preview-image-picture-card"> 
            <div className="preview-image-item">
                <div className="preview-image-item-info" >
                     <span>
                            <a className="preview-image-item-thumbnail" href={props.message.message}    target="_blank" >  
                                <img src={props.message.message} alt='xxx.png'/>
                            </a> 
                     </span>
                </div>
                <span className="preview-image-item-actions">
                     <Icon title="preview" type='eye-o' onClick={preView} />
                     <Icon title="download" type='download' onClick={download} />
                </span>
            </div>
       </div>);
    });
export default ImageMsg;