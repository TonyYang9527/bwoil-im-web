import React from 'react';
import { observer } from "mobx-react";
import { Icon, Avatar } from 'antd';
import randomColor from 'random-color';

const UserAvatar = (props) => {
    return (<Avatar shape="square" size="small" icon="team" style={{ backgroundColor: randomColor().hexString() }} />);
};
export default UserAvatar;