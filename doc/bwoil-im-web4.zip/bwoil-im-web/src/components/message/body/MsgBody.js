import React from 'react';
import { observer } from "mobx-react";
import MsgNotes from '../notes/MsgNotes';
import MsgWrapper from '../wrapper/MsgWrapper';

const MsgBody = observer((props) => {
    return (
        <div className='message-content'>
            <MsgWrapper message={props.message} />
            <MsgNotes message={props.message} />
        </div>
    );
});
export default MsgBody;
