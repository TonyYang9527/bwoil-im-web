import React from 'react';
import {observer} from "mobx-react";
import { Avatar } from 'antd';
import MsgBody from './body/MsgBody';
import './index.less';

const IMessage = observer((props) => {
   return (
       <div className='message-fromUser  message'>
            <MsgBody message={props.message} />
            <Avatar shape="square" size="small" icon="user" style={{ backgroundColor: '#5CB0FF' }} />
        </div>
    );
});

const UMessage = observer((props) => {
    return (
        <div className= 'message-fromGuest  message'>
            <Avatar shape="square" size="small" icon="user" style={{ backgroundColor: '#B0B0B0' }} />
            <MsgBody message={props.message} />
        </div>
    );
});

/*****TODO:check message owner****/
const checkMsgOwner = (fromUser)=>{
    return fromUser? true :false ; 
 }

const Message = observer((props) => {
    const message= checkMsgOwner(props.message.fromUser) ? <IMessage message={props.message} /> : <UMessage message={props.message} /> ;
    return (message);
});

export default Message;