import React from 'react';
import { observer } from "mobx-react";
import MsgStaus from '../status/MsgStaus';

const MsgNotes = observer((props) => {
    return (
        <span className='message-prompt'>
            <span className='message-time'>{props.message.time}</span>
            <MsgStaus status={props.message.status} />
        </span>
    );
});
export default MsgNotes;
