import React from 'react';
import { observer } from "mobx-react";
import ImageMsg from '../category/image/ImageMsg'
import TextMessage from '../category/text/TextMessage';
import OfferMessage from '../category/offer/OfferMessage';

const MsgWrapper = observer((props) => {
    if (props.message.type === "text") {
        return (<TextMessage message={props.message} />);
    } else if (props.message.type === "image") {
        return (<ImageMsg message={props.message} />);
    } else if (props.message.type === "sub") {
        return (<OfferMessage message={props.message} />);
    } else {
        return null;
    }
});
export default MsgWrapper;