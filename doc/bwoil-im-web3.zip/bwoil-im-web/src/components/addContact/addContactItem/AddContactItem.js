import React from 'react';
import {observer} from 'mobx-react';
import {Avatar, Checkbox} from 'antd';
import './AddContactItem.less';

import sessionStore from '../../../stores/SessionStore';

const AddContactItem = observer(({contact, store}) => {
        let {state, actions} = store;
        let {memberIds} = sessionStore.state.selected;
        let contain = memberIds ? memberIds.some((elem) => elem === contact.contactId) : false;
        console.log(memberIds, contact.contactId);
        return (
            <div
                className={contain || state.preAdd.has(contact.contactId) ? 'add-contact-item add-contact-item-focused' : 'add-contact-item'}>
                <div>
                    <span className='add-contact-icon'>
                        <Avatar src={process.env.PUBLIC_URL.concat("/assets/icon/user/").concat(contact.icon) }/>
                        <span className='add-contact-point'/>
                    </span>
                    <span className='add-contact-name'>{contact.contactName}</span>
                </div>
                <Checkbox checked={contain || state.preAdd.has(contact.contactId)} disabled={contain}
                          onChange={e => actions.preAdding(e.target.checked, contact)}/>
            </div>
        );
    }
);

export default AddContactItem;