import React from 'react';
import {observer} from "mobx-react";
import {Icon,Avatar} from 'antd';
import './Message.less';

import TextMessage from '../textMessage/TextMessage';
import ImageMessage from '../imageMessage/ImageMessage';
import OfferMessage from '../offerMessage/OfferMessage';
import  randomColor   from 'random-color';

const MessageStaus = observer((props) =>{
      if(props.status ==='sent'){
         return(<Icon type='check' style={{fontSize: 9, color: '#B0B0B0'}} />);
       }else if(props.status ==='received'){
         return(<Icon type='send' style={{fontSize: 9, color: '#B0B0B0'}} />);
       }else if(props.status ==='read'){
         return(<Icon type='read' style={{fontSize: 9, color: '#5CB0FF'}} />);
       }else {
         return null ;
       }
});

const UserAvatar = (props) =>{
   return (<Avatar  shape="square" size="small" icon="team" style={{ backgroundColor: randomColor().hexString()}} />) ;
};


const MessageFactory = observer((props)=>{

});

const Message = observer(({message}) => {

        const messageStyle = message.fromUser ? 'message-fromUser' : 'message-fromGuest';
        let mes = null;
      
        switch (message.type){
            case 'text':
                mes = <TextMessage message={message}/>;
                break;
            case 'image':
                mes = <ImageMessage message={message}/>;
                break;
            case 'sub':
                mes = <OfferMessage message={message}/>;
                break;
            default:
                mes = <TextMessage message={message}/>;
                break;
        }

        return (
            <div className={messageStyle + ' message'}>
               
                <div className='message-content'>
                    {mes}
                   <span className='message-prompt'>
                   <span className='message-time'>{message.time}</span>
                   <MessageStaus status={message.status} />
                   </span>
                </div>
                <Avatar  shape="square" size="small" icon="user" style={{ backgroundColor: '#e7e7e7'}} />
            </div>
        );
    }
);

export default Message;