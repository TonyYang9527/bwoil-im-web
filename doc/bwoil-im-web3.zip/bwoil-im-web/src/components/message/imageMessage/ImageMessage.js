import React from 'react';
import {observer} from "mobx-react";
import {Modal,Button,Icon,Avatar} from 'antd';
import './ImageMessage.less';


const PreImage = observer((props) => {
    const onCancel = (e) => {
        e.stopPropagation();
    };
    return (
        <Modal visible={true} footer={<Button type="primary" icon="download" >Download</Button>} onCancel={onCancel}>
           <img alt="example" style={{width: '100%'}} src={props.message.message} />  
       </Modal>
    );
});

const ImageMessage = observer(({message}) => {
        const imageStyle = message.fromUser ? 'imageMessage-fromUser' : 'imageMessage-fromGuest';

        const onCilck =(e)=>{
            console.log("ImageMessage onCilck ") ;
             e.stopPropagation();
        };
        return (
        <div className="ant-upload-list-picture-card"> 
        <div className="ant-upload-list-item">
          <div className="ant-upload-list-item-info" >
              <span>
                 <a className="ant-upload-list-item-thumbnail"  href={message.message}    target="_blank" >  
                   <img src={message.message} className={imageStyle}  alt='xxx.png'/>
                 </a> 
                 <a className="ant-upload-list-item-name"  href={message.message}    target="_blank"  title="xxx.png"> 
                    xxx.png 
                 </a>   
              </span>
          </div>
          <span className="ant-upload-list-item-actions">
            <a   href={message.message}    target="_blank" title ="Preview file" >  
              <Icon   type='eye-o'   />
            </a>   
             <Icon  title ="Preview file"   type='delete'   />
          </span>
       </div>
       </div>
        );
    }
);

export default ImageMessage;