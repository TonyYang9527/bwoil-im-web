import React from 'react';
import {observer} from 'mobx-react';
import Partner from '../message/partner/Partner';
import ContentTitle from '../message/contentTitle/ContentTitle';
import TextBox from '../message/textBox/TextBox';
import MessagesList from '../message/index';
import sessionStore from '../../stores/SessionStore';
import messageStore from '../../stores/MessageStore';
import addContactStore from '../../stores/AddContactStore';
import partnerStore from '../../stores/PartnerStore';

import './Content.less';

const ContentContainer = observer(() => {

    if (!sessionStore.state.selected){
        return <div className='content' />;
    }
    let name = sessionStore.state.selected.name ? sessionStore.state.selected.name : '';
    let count = sessionStore.state.selected.partners ? '(' + sessionStore.state.selected.partners.length + ')' : '';
    return (
        <div className='content'>
            <Partner/>
            <ContentTitle name={name} count={count}
                modalShow={partnerStore.state.modalShow}
                upDown={partnerStore.actions.upDown}
                openModal={addContactStore.actions.openModal}/>
            <MessagesList messages={messageStore.data.messages.values()} />
            <TextBox/>
        </div> 
    );
});

export {ContentContainer};
