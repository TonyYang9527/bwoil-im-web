import React from 'react';
import {Scrollbars} from 'react-custom-scrollbars';

/****Vertical***/
const renderThumbVertical = ({ style, ...props }) =>{
    const thumbStyle = { backgroundColor: '#5F5F5F', width: 4, right: -4 };
    return (<div style={{ ...style, ...thumbStyle }} {...props} />);
};
/****Horizontal***/
const renderThumbHorizontal = ({ style, ...props })=> {
    const thumbStyle = { visibility: 'hidden' };
    return (<div style={{ ...style, ...thumbStyle }} {...props} />);
};

const BwoilScrollbars = (props) => {
    let {getRef = (ref) => {}} = props;
    const cust_props = {
        renderThumbHorizontal: renderThumbHorizontal ,
        renderThumbVertical:   renderThumbVertical,
        thumbSize: 56 ,
        autoHide :true,
        autoHideTimeout: 1000,
        autoHideDuration:200
    };

  return (
      <Scrollbars ref={ref => getRef(ref) } {...cust_props} >
             {props.children}
         </Scrollbars>
       );
};
export default BwoilScrollbars;