import React from 'react';
import {observer} from 'mobx-react';
import {Avatar,Badge} from 'antd';
import  randomColor   from 'random-color';

const GAvatar = (props) => {
    return (<Avatar icon="team" style={{ backgroundColor: randomColor().hexString()}} /> );
};

const UAvatar = (props) => {
    return (
        <Badge dot  status={props.session.status}  offset={[29,-2]}>
            <Avatar icon="user" style={{ backgroundColor: randomColor().hexString()}} />
        </Badge>
    );
};

const UserAvatar = observer((props) => {
    const members = props.session.partners.length ;
    return (members>2? <GAvatar/>:<UAvatar session={props.session} />) ;
});

export default UserAvatar;