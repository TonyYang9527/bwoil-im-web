import React from 'react';
import {observer} from 'mobx-react';
import './Layout.css' ;

const style =  {width:1000,height:658,left:100,top:100,background: '#F9F9F9'};
const Laytout = observer((props) => {
    return (
        <div className="chartering" style={style}>
            {props.children}
        </div>
     );
});
export default  Laytout ;
