import React from 'react';
import {observer} from 'mobx-react';
import {Card} from 'antd';
import BwoilScrollbars from "../scrollbars/Scrollbars" ;
import UserAvatar from "./avatar/UserAvatar" ;
import './index.less';

const Contact = observer((props) => {
    const  avatar =(<UserAvatar contact={props.contact} />) ;
    const onClick = (e) => {
        console.log("Contact  onClick") ;
        props.addSession(props.contact);
        e.stopPropagation();
    };
    
    return (
        <Card  className='contact' onClick={onClick}>
           <Card.Meta avatar={avatar} title={<span>{props.contact.name}</span>} />
        </Card>
    );
});


const ContactList = observer((props) => {
    if(props.contacts.size <=0){
        return null ;
    }
    const contacts= props.contacts.map((item, index) =><Contact contact={item} key={index} addSession={props.addSession} />) ;
    return (
      <div style={{ width: 250, height: 572 }}> 
        <BwoilScrollbars >
          {contacts} 
        </BwoilScrollbars>
      </div>
      );
});

export {Contact ,ContactList} ;