import DateUtils from './DateUtils' ;

let  message ={
      id: 0,
      type: '',
      msgDetail: '',
      messageStatus: '',
      conversationId : '' ,
      sendTimeStr:'',
      random : '' ,
      senderId:'',
      sender :{
            senderId : '' ,
            senderName: '',
            senderIcon: ''
     }
};

const MessageBuilder = {

    transform:(convsId,type,msgDetail,random) => {
      let now = DateUtils.currentTimeStamp() ;
        message.id='' ;
        message.type=type ;
        message.msgDetail =msgDetail ;
        message.messageStatus ='' ;
        message.conversationId =convsId ;
        message.sendTime =now ;
        message.sendTimeStr =DateUtils.currentHHMM(now) ;
        message.random=random ;
        message.senderId = '194864903125730329' ;
        message.sender = {
            senderId : 'spider.png' ,
            senderName: '194864903125730329',
            senderIcon: 'spider.png'
        } ;
       return  message;
   }

} ;
export default MessageBuilder ;