import WebSocketClient from 'bmo-websocket-client';
import messageStore from '../stores/MessageStore' ;
import SessionStore from '../stores/SessionStore' ;
import UserStore from '../stores/UserStore' ;
import WebSocketConfig from "./webSocketConfig";
import UUID from '../tools/UUID' ;

const Listeners = { };
const openListener = () => {};
const errorListener = ({message}) => {
    console.log('CLIENT ERROR:',message);
};
const HEARTBEAT_ID = "THE_ID_OF_HEARTBEAT";
const connectedListener = ({status, message}) => {
    console.log('CLIENT CONNECTED:[' + status + ']');
    let heartbeat = [{
        "id": UUID.uuid(),
        "uri": "/im/user/online/heartbeat",
        "body": JSON.stringify({userId: UserStore.state.userId})
    }];
   
    setInterval(()=>{
        console.log('CLIENT SEND HEART BEAT :',heartbeat);
        WebSocketConfig.send(heartbeat);},60000);
};
const disconnectedListener = () => {
    console.log('CLIENT DISCONNECTED');
};
const connectionErrorListener = ({status, message}) => {
    console.log('CLIENT CONNECTED FAILED:' + status ,message);
};
const connectionUnacceptableListener = ({status, message}) => {
    console.log('CLIENT UNACCEPTABLE:',status ,message );
};
const eventSendingFailListener = ({status, message, eventId}) => {
        switch (eventId){
               case HEARTBEAT_ID : console.log('HEARTBEAT SENDED FAILED:' );break;
               default : console.log('CLIENT SENDED FAILED:',status, message ,'EVENT:' + eventId );
         }
};

const eventSendingSuccessListener = ({eventId}) => {
    switch (eventId){
           case HEARTBEAT_ID : 
           console.log('HEARTBEAT SENDED SUCCESS:' );
           break;
           default :{
            console.log('CLIENT SENDED SUCCESS:',eventId);
            let random = eventId ;
            messageStore.actions.updateMsgStatus(random ,"sent") ;
           } 
    }
};

 /**message**/
 const  eventChangeMessageListener= ({eventName, eventData}) => {
       console.log('MESSAGE NOTIFY :',eventName ,eventData);
       messageStore.actions.addOrUpdateMessage(eventData.msgAddOrUpdata) ; 
};
/**conversation*/
const eventChangeConvsListener = ({eventName, eventData}) => {
     console.log('CONVERSATION  NOTIFY: ',eventName , JSON.stringify(eventData));
     SessionStore.actions.refreshConvs(eventData.covsAddOrUpdate);
};
const eventDeleteConvsListener = ({eventName, eventData}) => {
    console.log('DELETE CONVERSATION NOTIFY :', eventName ,JSON.stringify(eventData));
    SessionStore.actions.refreshConvs(eventData.covsDel);
};

/**contact**/
const eventChangeContactListener = ({eventName, eventData}) => {
    console.log('CONTACT  NOTIFY:', eventName ,JSON.stringify(eventData));
   // SessionStore.actions.refreshConvs(eventData.contactAddOrUpdate);
};
const eventDeleteContactListener = ({eventName, eventData}) => {
    console.log('DELETE  CONTACT NOTIFY :', eventName ,JSON.stringify(eventData));
     // SessionStore.actions.refreshConvs(eventData.contactDel);
};
/******User********/
const eventUserStateListener = ({eventName, eventData}) => {
    console.log('USER STATE:', eventName ,JSON.stringify(eventData));
};

Listeners[WebSocketClient.listenerType.OPEN] = openListener;
Listeners[WebSocketClient.listenerType.ERROR] = errorListener;
Listeners[WebSocketClient.listenerType.CONNECTED] = connectedListener;
Listeners[WebSocketClient.listenerType.DISCONNECTED] = disconnectedListener;
Listeners[WebSocketClient.listenerType.CONNECTION_ERROR] = connectionErrorListener;
Listeners[WebSocketClient.listenerType.CONNECTION_UNACCEPTABLE] = connectionUnacceptableListener;
Listeners[WebSocketClient.listenerType.SENDING_FAILURE] = eventSendingFailListener;
Listeners[WebSocketClient.listenerType.SENDING_SUCCESS] = eventSendingSuccessListener;
/**message event**/
Listeners['/im/message/add-update'] = eventChangeMessageListener;
/**conversation event**/
Listeners['/im/conversation/add-update'] = eventChangeConvsListener;
Listeners['/im/conversation/delete'] = eventDeleteConvsListener;
/**contact event**/
Listeners['/im/contact/add-update'] = eventChangeContactListener;
Listeners['/im/contact/delete'] = eventDeleteContactListener;
/**contact event**/
Listeners['/im/user/state'] = eventUserStateListener;

export default Listeners;