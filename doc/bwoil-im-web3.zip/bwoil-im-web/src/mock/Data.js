export const messages = [
    {
        id: '10002',
        type: "text",
        msgDetail: "I am customer service  , Glad to chat with  you. ",
        messageStatus: "sent",
        conversationId : '194871711538085890' ,
        sendTimeStr:"14:49",
        senderId:"194864903125730329",
		sender :{
		  senderId : '194864903125730329' ,
          senderName: 'King',
		  senderIcon: process.env.PUBLIC_URL.concat("/assets/icon/user/antman.png")
		}
    },
    {
	    conversationId : '194871711538085890' ,
        id: '10003',
        type: "image",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "received",
        sendTimeStr: "02:49",
        senderId:"194864903125730329",
    	sender :{
		  senderId : '194864903125730329' ,
          senderName: 'King',
		  senderIcon: process.env.PUBLIC_URL.concat("/assets/icon/user/atom.png")
		}
    },
    {
	
	    conversationId : '194871711538085890' ,
        id: '10004',
        type: "text",
        msgDetail: "Hi Jim, I have some issues ..",
        messageStatus: "read",
        sendTimeStr: "02:49",
        senderId:"194864903125730329",
		 sender :{
		  senderId : '194864903125730329' ,
          senderName: 'Jack',
		  senderIcon: process.env.PUBLIC_URL.concat("/assets/icon/user/batmen.png")
		}
    },
    {
	    conversationId : '194871711538085890' ,
        id: '10005',
        type: "text",
        msgDetail: "What is  issues?",
        messageStatus: "read",
        sendTimeStr: "02:49",
        senderId:"194864903125730329",
		  	sender :{
		  senderId : '194864903125730329' ,
          senderName: 'Mike',
		  senderIcon: process.env.PUBLIC_URL.concat("/assets/icon/user/captain.png")
		}
    },
     {
	    conversationId : '194871711538085890' ,
        id: '10006',
        type: "text",
        msgDetail: "After install the bmo-rest-client, you need to create a apiConfig file in your project under service folder All your API used in your project will be set in apiConfig",
        messageStatus: "sent",
        sendTimeStr: "02:49",
        senderId:"194591581423010841",
		 sender :{
		   senderId : '194591581423010841' ,
          senderName: 'Mike',
		  senderIcon: process.env.PUBLIC_URL.concat("/assets/icon/user/flash.png")
		}
    },
    {
	
	    conversationId : '194871711538085890' ,
        id: '10007',
        type: "image",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "received",
        sendTimeStr: "02:49",
        senderId:"194591581423010841",
		 sender :{
		    senderId : '194591581423010841' ,
           senderName: 'williness',
		   senderIcon: process.env.PUBLIC_URL.concat("/assets/icon/user/greenman.png")
		}
    },
    {
	
	    conversationId : '194871711538085890' ,
        id: '10008',
        type: "pdf",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "received",
        sendTimeStr: "02:49",
        senderId:"194591581423010841",
		sender :{
		  senderId : '194591581423010841' ,
          senderName: 'williness',
		  senderIcon: process.env.PUBLIC_URL.concat("/assets/icon/user/hulk.png")
		}
    } ,
    {
	
	    conversationId : '194591581423010841' ,
        id: '10009',
        type: "doc",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "received",
        sendTimeStr: "02:49",
        senderId:"194864903125730329",
		 sender :{
		   senderId : '194864903125730329' ,
          senderName: 'williness',
		  senderIcon: process.env.PUBLIC_URL.concat("/assets/icon/user/ironman.png")
		}
    },

    {
	
	    conversationId : '194871711538085890' ,
        id: '10010',
        type: "txt",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "received",
        sendTimeStr: "02:49",
        senderId:"194864903125730329",
		 sender :{
	      senderId : '194864903125730329' ,
          senderName: 'williness',
		  senderIcon: process.env.PUBLIC_URL.concat("/assets/icon/user/spider.png")
		}
    },

    {
	    conversationId : '194871711538085890' ,
        id: '10011',
        type: "xls",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "received",
        sendTimeStr: "02:49",
        senderId:"194864903125730329",
		sender :{
		  senderId : '194864903125730329' ,
          senderName: 'williness',
		  senderIcon: process.env.PUBLIC_URL.concat("/assets/icon/user/superman.png")
		}
    },
    {  
	    conversationId : '194871711538085890',
        id: '10012',
        type: "ppt",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "received",
        sendTimeStr: "02:49",
        senderId:"194864903125730329",
		sender :{
		   senderId : '194864903125730329' ,
          senderName: 'williness',
		  senderIcon: process.env.PUBLIC_URL.concat("/assets/icon/user/superman.png")
		}
    }
];

export const profiles = {
    vessel: 'BRIGHTOIL GLORY',
    sector: 'Oil Tanker',
    openDate: '01/01/2018',
    openPorts: 'Singapore,China, Indonesia,India',
    cargoVessel: 'PIG IRON,5000MT',
    laycanDate: '01-05 Jan 2018',
    voyage: 'Singapore>Shanghai',
    loadRate: '1500/1500',
    addressComission: '3.75%',
    freight: 'SGD:15/MTS'
};

export const cargo = {
    cargo: 'PIG IRON,5000MT',
    laycanDate: '01-05 Jan 2018',
    voyage: 'Singapore>Shanghai',
    loadRate: '1500/1500',
    addressComission: '3.75%',
    freight: 'SGD:15/MTS'
};

export const vessel = {
    vessel: 'BRIGHTOIL GLORY',
    sector: 'Oil Tanker',
    openDate: '01/01/2018',
    openPorts: 'Singapore,China, Indonesia,India'
};


export const step = {
    current: 1,
    status: 'finish'
};

export const conversations = [
    {
        id : 101,
        name :'Jim King,Yang Sun,Qiaomin Jin',
        icon :process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        states :'success',
        unreadMsg :[123,122,1234] ,
        newMsg: {msgId :'dddd' , sendTime:'02:49' ,msgContent : 'hi this is new message'} ,
        memberIds :[194864903125730329, 194591581423010841] 	  
    } 
];

export const contacts = [
    {
        id: 200,
        name: "Jim King",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 201,
        name: "Yang Sun",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "default"
    },
    {
        id: 202,
        name: "QiaoMin Jin",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 203,
        name: "Jake Li",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "default"
    },
    {
        id: 204,
        name: "Standly McNair",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 205,
        name: "Charles Smith",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 106,
        name: "Kelli Ortiz",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 107,
        name: "Tony Yang",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "success"
    },
    {
        id: 108,
        name: "Lebron James",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "success"
    },
    {
        id: 109,
        name: "Embid",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "success"
    },
    {
        id: 110,
        name: "Durant",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 111,
        name: "Howard",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 112,
        name: "Wade",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 113,
        name: "Anthony",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 114,
        name: "George",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 115,
        name: "WhiteSide",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "success"
    }
];