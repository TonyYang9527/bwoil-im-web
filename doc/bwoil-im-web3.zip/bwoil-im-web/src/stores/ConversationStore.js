import {observable, action, autorun, when} from 'mobx';
import messageStore from './MessageStore';
import userStore from './UserStore'
import WebSocketConfig from '../services/webSocketConfig';
import {RestClient} from "bmo-rest-client";
import apiConfig from "../services/apiConfig";
import UUID from '../tools/UUID' ;
import MessageBuilder from '../tools/MessageBuilder' ;

const data = observable({
    id: 0,
    textArea: null,
    text: '',
});

const actions = {
    init: action((id) => {
        if (data.id !== id) {
            data.id = `${id}`;
            data.text = '';
        }
    }),
    onFocus: action((e) => {
        if (!data.textArea) {
            data.textArea = e.target;
        }
    }),
    onChange: action((e) => {
        data.text = e.target.value;
    }),

    sendMessage: action((e) => {
        e.preventDefault();
        let random =UUID.uuid() ;
        let messages =[{"covsId":messageStore.data.id,"msgContent": data.text,"senderId": userStore.state.userId,"msgType": 1 ,'random' :random}];
        let msg = [{'id':random,'uri':'/im/message/add','body': JSON.stringify(messages)}];
        console.log("messages " ,msg) ;
        WebSocketConfig.send(msg);
        data.text = '' ;   
       let message = MessageBuilder.transform(messageStore.data.id,1,data.text,random) ;
       // messageStore.actions.addOrUpdateMessage(message) ;
        messageStore.actions.scrollToBottom();
    }),
    sendMsg: action((e) => {
        e.preventDefault();
        let param = [{senderId:userStore.state.userId, covsId: messageStore.data.id,msgContent:data.text ,msgType:1 }];
        RestClient.call(apiConfig.messageAdd, null, param).then(res => {
                res.data.forEach(item =>{
                  console.log("messageList item" ,item);
                  messageStore.data.messages.set(item.id, item);
                });
            });
        data.text = '' ; 
    }) 
};

when(
    () => !data.textArea,
    () => {
        WebSocketConfig.getToken();
    }
);


autorun(() => {
    if (data.text) {
        if (data.textArea.scrollHeight > data.textArea.clientHeight) {
            if (!data.textArea.classList.contains('with-scrollbar')) {
                data.textArea.classList.add('with-scrollbar');
            }
        } else {
            if (data.textArea.classList.contains('with-scrollbar')) {
                data.textArea.classList.remove('with-scrollbar');
            }
        }
    } else {
        if (data.textArea) {
            data.textArea.focus();
        }
        messageStore.actions.scrollToBottom();
    }
});

export default {data, actions};