import {observable, action, autorun, when} from 'mobx';

import globalStore from './GlobalStore';
import messageStore from './MessageStore';
import profileStore from './ProfileStore';
import addContactStore from './AddContactStore';
import partnerStore from './PartnerStore';
import {RestClient} from 'bmo-rest-client';
import apiConfig from '../services/apiConfig';
import userStore from '../stores/UserStore';
import SessionUtil from '../tools/SessionUtil';


const state = observable({
    sessions: observable.map(),
    selected: {},
    copy: {}
});

const actions = {
    init: action((sessions) => {
        sessions.forEach((covns) => {
            covns.className = "conversation";
            covns.modalVisible = false;
            state.sessions.set(covns.id, covns);
        });
    }),

    select: action((covnsId) => {
            state.selected = state.sessions.get(covnsId);
            console.log("Conversation  onClick selected" ,state.selected);
            state.selected.unreadMsg = [];
            actions.changeStyle(covnsId);
            /**please call other api**/
             messageStore.actions.init(covnsId);
             profileStore.actions.init(covnsId);
             partnerStore.actions.reset();
             globalStore.actions.restoreTab();
    }),

    getSelected: () => {
        return   state.selected ;
     },
    addOrUpdateConvs:action((covns) => {
        
         covns.className = "conversation";
         covns.modalVisible = false;
         state.sessions.set(covns.id, covns);
      }),

    add: action((contact) => {
        /**TODO: please call add api**/
        let userId = userStore.state.userId;
        let userIds = [userId, contact.contactId];
        RestClient.call(apiConfig.covsAdd,null,{userIds: userIds,createBy: userId})
            .then(res => {
                console.log("contact rename res :" ,res) ;
                let covns= res.data;
                covns.className = "conversation";
                covns.modalVisible = false;
                state.sessions.set(covns.id, covns);
                actions.changeStyle(covns.id);
                globalStore.actions.restoreTab();
            });
    }),

    onOk: action((opt, covsId) => {
        if (opt === "1") { //delete conversation
            let userId = userStore.state.userId;
            RestClient.call(apiConfig.covsDelete, null, {userId: userId, covsId: covsId})
                .then(res =>{
                    if(res.data.result) {
                        state.sessions.delete(covsId);
                    }
                });
            state.sessions.get(covsId).modalVisible=false ;   
        } else if (opt === "2") { //rename conversation
            let {userId} = userStore.state;
            let {name} = state.sessions.get(covsId);
            RestClient.call(apiConfig.covsUpdate,null,{userId: userId, covsId: covsId, name:name})
                    .then(res =>{
                        console.log("contact rename res :" ,res) ;
                    }); 
            state.sessions.get(covsId).modalVisible=false ;        
        } else if (opt === "3") { //exit  conversation
            let {userId} = userStore.state;
            let {users} = state.sessions.get(covsId);
            let tempUsers = users.filter(elem => elem !== userId);
            let temp = {userId: userId, covsId: covsId, userIds: tempUsers};
            RestClient.call(apiConfig.covsUpdate, null, temp)
                .then(res => {
                    let {id, users} = res.data.data;
                    let contain = users ? users.some(elem => elem === userId) : false;
                    if (!contain) {
                        state.sessions.delete(id);
                    }
                });
            state.sessions.get(covsId).modalVisible=false ; 
        }
    }),

    onCancel: action((opt, id) => {
        if (opt === "2") {
            state.sessions.get(id).name = state.copy.name;
            state.sessions.get(id).modalVisible = false;
        } else if (opt === "1" || opt === "3") {
            state.sessions.get(id).modalVisible = false;
        } else {
            //  do  nothing
        }
    }),

    dropdown: action((key, session) => {
        session.modalVisible = true;
        session.opt = key;
        state.copy = {id: session.id, opt: key, name: session.name};
    }),

    addContact: action((id, preAdd) => {
        /**TODO: please call invite  api**/
        let {userId} = userStore.state;
        let memberIds= state.selected.memberIds;
        let userIds = memberIds.concat(preAdd.map(elem => elem.id));
        let temp = {userId: userId, covsId: id, userIds: userIds};
        RestClient.call(apiConfig.covsUpdate, null, temp)
            .then(res => {
                console.log(res.data);
                let {data} = res.data;
                data.status = SessionUtil.getStatus(data.states);
                data.time = SessionUtil.getLocalTime(data.updateTime);
                data.className = "conversation conversation-focused";
                data.modalVisible = false;
                state.sessions.set(data.id, data);
                state.selected = state.sessions.get(id);
                addContactStore.actions.closeModal();
            });
    }),

    changeStyle: action((id) => {
        state.sessions.forEach((value, key, map) => {
            if (key === id) {
                value.className = 'conversation conversation-focused';
            } else {
                value.className = 'conversation';
            }
        });
    }),
};

when(
    () => !state.sessions.size,
    () => {
        RestClient.call(apiConfig.covsList, null,{userId: userStore.state.userId})
            .then(res =>{ 
                actions.init(res.data);
            });
         }
);

autorun(() => {
    if (state.selected.partners) {
        partnerStore.actions.closeModal();
    }
});

export default {state, actions};