import {observable, action} from 'mobx';
import {RestClient} from "bmo-rest-client";
import apiConfig from "../services/apiConfig";


const state = observable({
       userId: '194864903125730329',
       email: '' ,
       name: 'John'
  });

const actions = {
    
     setUserId: action((id) => {
        state.userId = id;
     }),

    queryUers: action((userIds) => {
          let result = '' ;
          RestClient.call(apiConfig.getUsers,null,userIds).then(res=>result =res.data); 
         return result ;
    })  
};

export default {state, actions}