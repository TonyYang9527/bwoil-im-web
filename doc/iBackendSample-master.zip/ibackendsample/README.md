# Overview

sample using iBackend framework.


# FAQ 

Q1: Eclipse start failed error message : eclipse java was started but returned exit code=1

A1: re-install latest version Eclipse
