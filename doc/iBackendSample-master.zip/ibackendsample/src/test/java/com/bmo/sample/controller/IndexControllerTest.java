package com.bmo.sample.controller;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.bmo.ibackend.Application;
import com.bmo.ibackend.controller.IndexController;
import com.bmo.ibackend.initializer.PropertyInitializer;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= {IndexController.class})
@Import(Application.class)
@Transactional
@ContextConfiguration(initializers = PropertyInitializer.class)
public class IndexControllerTest {
	@Autowired
	IndexController idxCtr;

	@Test
	public void ping() {
		assertNotNull(idxCtr.ping());
	}

}
