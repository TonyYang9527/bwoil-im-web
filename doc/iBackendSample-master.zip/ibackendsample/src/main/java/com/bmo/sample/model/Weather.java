package com.bmo.sample.model;

import com.bmo.ibackend.persistence.Column;
import com.bmo.ibackend.persistence.Id;
import com.bmo.ibackend.persistence.Table;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@Data
@Table
public class Weather {
	@Id
	@Column
	String id;
	@Column
	String city;
	@Column
	String name;
	@Column
	String img;
	@Column
	String degree;
	
}
