package com.bmo.sample.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bmo.ibackend.persistence.SQLQuery;
import com.bmo.sample.model.City;
import com.bmo.sample.model.Weather;

@Component
@Transactional
public class WeatherDao {
	
	public List<Weather> findAll() {
		return SQLQuery.sql(Weather.class,"select * from weather").all();
	}
	
	public Weather findByCity(String city) {
		return Weather.where("city = ?", city).first();
	}
	
	public int count() {
		int totalRecords = SQLQuery.sql(City.class,"select * from weather").all().size();
		return totalRecords;
	}
}
