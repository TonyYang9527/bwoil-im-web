package com.bmo.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bmo.sample.dao.WeatherDao;
import com.bmo.sample.model.Weather;

@Component
@Transactional
public class WeatherService{
	@Autowired
	WeatherDao weatherDao;
	
	public Weather getById(String id) {
		return Weather.findById(id);
	}
	
	public List<Weather> getAll() {
		return weatherDao.findAll();
	}
	
	public void createOrUpdate(Weather target) {
		target.saveOrUpdate();
	}
	
	public Weather getByCity(String city) {
		return weatherDao.findByCity(city);
	}
	
	public int getTotalRecords() {
		return weatherDao.count();
	}
}
