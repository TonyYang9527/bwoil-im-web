package com.bmo.sample.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bmo.sample.dao.CityDao;
import com.bmo.sample.model.City;

@Component
@Transactional
public class CityService{
	
	@Autowired
	private CityDao cityDao;
	
	public City getById(Long id) {
		return City.findById(id);
	}
	
	public List<City> getAll() {
		return cityDao.findAll();
	}
	
	public List<City> getByPage (int pageSize, int start) {
		return cityDao.findByPage(pageSize, start);
	}
	
	public void createOrUpdate(City target) {
		target.setUpdated(new Date());
		target.saveOrUpdate();
	}
	
	public void delete(Long id) {
		City.deleteById(id);
	}
	
	public int getTotalRecords() {
		return cityDao.count();
	}
	
	

	
}
