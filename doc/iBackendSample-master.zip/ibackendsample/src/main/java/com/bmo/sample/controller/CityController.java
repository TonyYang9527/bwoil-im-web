package com.bmo.sample.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bmo.ibackend.RestClient.PaginationRequest;
import com.bmo.ibackend.RestClient.PaginationResponse;
import com.bmo.ibackend.service.EventManager;
import com.bmo.sample.model.City;
import com.bmo.sample.service.CityService;

@RestController
@RequestMapping("/cities")
@Transactional
public class CityController {

	@Autowired
	private CityService citySvc;
	@Autowired
	private EventManager evtMgr;

	@GetMapping
	public PaginationResponse<City> getAllCities() {
		List<City> lstCity = citySvc.getAll();
		int totalRecords = citySvc.getTotalRecords();
		return new PaginationResponse<City>(totalRecords, lstCity);
	}
	
	@PostMapping("/page")
	public PaginationResponse<City> getCitiesWithPagination(@RequestBody(required = true) PaginationRequest<City> pagination) {
		List<City> lstCity = citySvc.getByPage(pagination.getPageSize(), pagination.getStart());
		int totalRecords = citySvc.getTotalRecords();
		return new PaginationResponse<>(totalRecords, lstCity);

	}

	@GetMapping("/{id}")
	public City getCityById(@PathVariable(required = true) String id) {
		return citySvc.getById(Long.valueOf(id));

	}

	@PostMapping
	public void createCity(@RequestBody(required = true) City city) {
		city.setId(null);
		citySvc.createOrUpdate(city);
	}

	@PutMapping("/{id}")
	public void updateCity(@PathVariable(required = true) String id, @RequestBody(required = true) City city) {
		city.setId(Long.valueOf(id));
		city.setUpdated(new Date());
		citySvc.createOrUpdate(city);
	}

	@DeleteMapping("/{id}")
	public void deleteCity(@PathVariable(required = true) String id) {
		citySvc.delete(Long.valueOf(id));
	}
	
	@PostMapping("/create-by-event")
	public void createCityByEvent(@RequestBody(required = true) City city) {
		evtMgr.fireEvent("CreateCity", city);
	}
	
	@DeleteMapping("/cancel-by-event/{id}")
	public void cancelCreateCityByEvent(@PathVariable(required = true) String id) {
		evtMgr.cancelEvent("CreateCity", id);
	}

}
