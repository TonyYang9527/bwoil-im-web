package com.bmo.sample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bmo.ibackend.RestClient.PaginationResponse;
import com.bmo.sample.model.Weather;
import com.bmo.sample.service.WeatherService;

@RestController
@RequestMapping("/weathers")
public class WeatherController {
	@Autowired
	WeatherService weatherSvc;

	@GetMapping
	public PaginationResponse<Weather> getAllWeathers(){
		List<Weather> lstWeather = weatherSvc.getAll();
		int totalRecords = weatherSvc.getTotalRecords();
		return new PaginationResponse<Weather>(totalRecords, lstWeather);
	}
	
	@GetMapping("/{city}")
	public Weather getWeatherByCity(@PathVariable(value="city", required=true) String city){
		return weatherSvc.getByCity(city);
	}
	
}
