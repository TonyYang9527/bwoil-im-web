package com.bmo.sample.listener;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bmo.ibackend.event.CancelEventListener;
import com.bmo.ibackend.event.EventName;
import com.bmo.sample.model.City;

import lombok.extern.slf4j.Slf4j;

@Component
@EventName("CreateCity")
@Slf4j
@Transactional
public class CancelCreateCityListener implements CancelEventListener<Long>{
	
	@Override
	public void onCancel(Long id) {
		try {
			City.deleteById(id);
			log.info("City deleted");
		}catch(Exception e) {
			log.error("City create failed");
		}
	}
}