package com.bmo.sample.model;

import java.util.Date;

import com.bmo.ibackend.persistence.Column;
import com.bmo.ibackend.persistence.Id;
import com.bmo.ibackend.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@Table
@JsonIgnoreProperties(value = {"id" })//for jackson to ignore when parsing response
public class User {
	@Id @Column @ApiModelProperty(hidden = true)
	String id;
	@Column
	String name;
	@Column
	Date created;
}
