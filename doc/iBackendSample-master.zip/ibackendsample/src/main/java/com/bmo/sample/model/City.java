package com.bmo.sample.model;

import com.bmo.ibackend.persistence.Column;
import com.bmo.ibackend.persistence.Id;
import com.bmo.ibackend.persistence.Table;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@Data
@Table
public class City {
	@Id
	@Column
	Long id; // SQL Type: VARCHAR size:64
	@Column
	String name; // SQL Type: VARCHAR size:64
	@Column
	String img; // SQL Type: VARCHAR size:128
	@Column
	java.util.Date updated; // SQL Type: TIMESTAMP size:19
}
