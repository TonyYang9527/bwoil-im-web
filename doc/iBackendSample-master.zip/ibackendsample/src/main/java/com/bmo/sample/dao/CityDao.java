package com.bmo.sample.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bmo.ibackend.persistence.SQLQuery;
import com.bmo.sample.model.City;

@Component
@Transactional
public class CityDao {
	
	public List<City> findAll() {
		List<City> data = SQLQuery.sql(City.class,"select * from city").all();
		return data;
	}
	
	public City findByName(String name) {
		return City.where("name = ?", name).first();
	}
	

	public List<City> findByPage (int pageSize, int start) {		
		List<City> data = SQLQuery.sql(City.class,"select * from city LIMIT ? OFFSET ?" , pageSize, start).all();
		return data;
	}
	
	public int count() {
		int totalRecords = SQLQuery.sql(City.class,"select * from city").all().size();
		return totalRecords;
	}
	
}
