package com.bmo.sample.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bmo.ibackend.event.EventListener;
import com.bmo.ibackend.event.EventName;
import com.bmo.ibackend.service.EventManager;
import com.bmo.sample.model.City;

import lombok.extern.slf4j.Slf4j;

@Component
@EventName("CreateCity")
@Slf4j
@Transactional
public class CreateCityListener implements EventListener<City>{
	@Autowired
	private EventManager eventMgr;
	
	@Override
	public void onEvent(City city) {
		try {
			city.saveOrUpdate();
			log.info("City created");
		}catch(Exception e) {//failure leads to a cancel event
			eventMgr.cancelEvent("CreateCity", city);
			log.error("City create failed");
		}
		
	}
}

