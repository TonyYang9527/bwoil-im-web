DROP TABLE IF EXISTS `city`;
CREATE TABLE `city` (
  `id` bigint(18) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `img` varchar(128) DEFAULT NULL,
  `updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `city` VALUES (190367522158018562,'Singapore','/assets/singapore.jpg','2018-03-26 15:16:20'),(190367561232154626,'Johor Bahru','/assets/jb.jpg','2018-03-26 15:16:20'),(190367580274294786,'Kuala Lumpur','/assets/kl.jpg','2018-04-10 13:16:54'),(190367590122520578,'Bei Jing','/assets/bj.jpg','2018-03-24 18:22:59');

DROP TABLE IF EXISTS `weather`;
CREATE TABLE `weather` (
  `id` varchar(64) NOT NULL,
  `city` varchar(64) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `img` varchar(128) DEFAULT NULL,
  `degree` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `weather` VALUES ('190391294550343682','Singapore','Day Cloudy','https://image.ibb.co/hbAgtS/day_cloudy.gif','39'),('190391304482455554','Johor Bahru','Night Shower','https://image.ibb.co/kVxSYS/night_shower.gif','35'),('190391313038835714','Kuala Lumpur','Night Cloudy','https://image.ibb.co/kitO7n/night_cloudy.gif','34'),('190391322769620994','Bei Jing','Day Shower','https://image.ibb.co/gTfQL7/day_shower.gif','32');