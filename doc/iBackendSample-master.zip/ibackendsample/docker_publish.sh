#!/bin/sh
#This script will: (1) build application jar file with gradle; (2) build docker image with jar file; (3) publish docker image to nexus
gradle clean build -x test
docker build -t registry.pm.bwoilmarine.com/$1:v$2 .
docker push registry.pm.bwoilmarine.com/$1:v$2