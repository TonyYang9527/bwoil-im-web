import * as moment from 'moment';

const DATE_FORMAT ={
  HHMM : moment.HTML5_FMT.TIME ,
};
const DateUtils = { 
  currentTimeStamp:() => {
      return moment().toDate().getTime();
   },
  currentHHMM:(timestamp) => {
       return moment(timestamp).format(DATE_FORMAT.HHMM) ;
  }
};
export default DateUtils ;