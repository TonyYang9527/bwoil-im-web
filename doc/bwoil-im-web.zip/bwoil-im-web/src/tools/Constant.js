
const Constant = {
    MSG_STATUS :{ SEND:1,PART_READ:2,ALL_READ:3},
    MSG_TYPE: {TEXT:1,IMAGE:2},
    ICONPATH :process.env.PUBLIC_URL.concat("/assets/icon/user/") ,
    USER_STATUS:{OFFLINE:0,ONLINE:1},
}
export default Constant;