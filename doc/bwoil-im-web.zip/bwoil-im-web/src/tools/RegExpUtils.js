const RegExpUtils = { 
     isImage : (str) => {
        const strRegex = "(.jpg|.png|.gif|.jpeg)$";
        const regExp = new RegExp(strRegex);
        return regExp.test(str.toLowerCase());
    },

     isMicroOffice : (str) => {
        const strRegex = "(.pdf|.doc|.txt|.xls|.ppt)$";
        const regExp = new RegExp(strRegex);
        return regExp.test(str.toLowerCase());
    },
    
    isNull:(str)=>{
        return !str && str!==0 && typeof str!=="boolean"?true:false;
    }
} ;
export default RegExpUtils ;