import { Endpoint, Request } from 'bmo-rest-client';

const apiConfig = {

     /*****conversation API********/
    covsList: Endpoint(Request.POST,   "/im/conversation/list"),
    covsAdd:  Endpoint(Request.POST,   "/im/conversation/add"),
    covsUpdate: Endpoint(Request.POST, "/im/conversation/update"),
    covsDelete: Endpoint(Request.POST, "/im/conversation/delete"),
    covsPagination: Endpoint(Request.POST, "/im/conversation/pagination"),
    /*****contact API********/
    contactList: Endpoint(Request.POST,   "/im/contact/list"),
    contactAdd: Endpoint(Request.POST,    "/im/contact/add"),
    contactUpdate: Endpoint(Request.POST, "/im/contact/update"),
    contactDelete: Endpoint(Request.POST, "/im/contact/delete"),
    contactPagination: Endpoint(Request.POST, "/im/contact/pagination"),
};

/******
let  urlParam  ={country: country, port: port} ;
let  bodyParam ={country: country, port: port} ;
RestClient.call(apiConfig.getFormFields, urlParam, bodyParam)
.then(res => {
    console.log(res.data);
 }).catch(error =>{
    if (error.response) {
     console.log('Error response', error.response);
    }else if (error.request){
     console.log('Error request', error.request);
    }else {
      console.log('Error', error.message);
    }
 });
*****/
export default apiConfig;