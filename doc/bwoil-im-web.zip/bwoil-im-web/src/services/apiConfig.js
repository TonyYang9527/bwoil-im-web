import {Endpoint, Request} from 'bmo-rest-client';

const apiConfig = {
    /*****login API********/
    login: Endpoint(Request.POST, "/sso/u/login"),
    /*****conversation API********/
    covsList: Endpoint(Request.POST, "/im/conversation/list"),
    covsAdd: Endpoint(Request.POST, "/im/conversation/add"),
    covsUpdate: Endpoint(Request.POST, "/im/conversation/update"),
    covsDelete: Endpoint(Request.POST, "/im/conversation/delete"),
    covsPagination: Endpoint(Request.POST, "/im/conversation/pagination"),
    /*****contact API********/
    contactList: Endpoint(Request.GET, "/im/contact/{userId}"),
    contactAdd: Endpoint(Request.POST, "/im/contact/add"),
    contactUpdate: Endpoint(Request.POST, "/im/contact/update"),
    contactDelete: Endpoint(Request.POST, "/im/contact/delete"),
    contactPagination: Endpoint(Request.POST, "/im/contact/pagination"),
    /*****message API********/
    messageList: Endpoint(Request.POST, "/im/message/list"),
    messageAdd: Endpoint(Request.POST, "/im/message/add"),
     /*****user API********/
    getUsers: Endpoint(Request.POST, "/im/user/list"),
};

export default apiConfig;