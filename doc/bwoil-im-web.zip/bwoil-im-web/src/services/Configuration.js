const ws_config={ 
      proxy: 'http://www.sit1.bwoilmarine.com',
      serviceName: 'im',
      authorization: '',
      listeners: '',
      logging: false
  };

const Configuration = {
       init:(token,listeners)=>{
           ws_config.authorization =token ;
           ws_config.listeners = listeners ; 
          return ws_config  ;
        }
 
} ;

export default Configuration;