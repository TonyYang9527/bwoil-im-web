import WebSocketClient from 'bmo-websocket-client';
import apiConfig from '../services/apiConfig';
import {RestClient} from 'bmo-rest-client';

let openListener = () => {
    console.log('connection opened');
};

let errorListener = ({message}) => {
    console.log('server error occurred, message: [' + message + ']');
};

let connectedListener = ({status, message}) => {
    console.log('connection established, status:[' + status + '], message:[' + message + ']');
    console.log('连接成功');
};

let disconnectedListener = () => {
    console.log('websocket disconnected');
};

let connectionErrorListener = ({status, message}) => {
    console.log('websocket connection error occurred, status:[' + status + '], message:[' + message + ']');
};

let connectionUnacceptableListener = ({status, message}) => {
    console.log('websocket connection unacceptable, status:[' + status + '], message:[' + message + ']');
};

let eventSendingFailListener = ({status, message, eventId}) => {
    console.log('event sending message failure: ' + status + ' - ' + message + ' for event ' + eventId + '.');
};

let eventSendingSuccessListener = ({eventId}) => {
    console.log('event sending message success: ' + eventId);
};

let customlizedEvent1Listener = ({eventName, eventData}) => {
    console.log('customlized service 1 message from backend : ' + eventName + ' - ' + JSON.stringify(eventData));
};

let customlizedEvent2Listener = ({eventName, eventData}) => {
    console.log('customlized service 2 message from backend : ' + eventName + ' - ' + JSON.stringify(eventData));
};

let listeners = {};
listeners[WebSocketClient.listenerType.OPEN] = openListener;
listeners[WebSocketClient.listenerType.ERROR] = errorListener;
listeners[WebSocketClient.listenerType.CONNECTED] = connectedListener;
listeners[WebSocketClient.listenerType.DISCONNECTED] = disconnectedListener;
listeners[WebSocketClient.listenerType.CONNECTION_ERROR] = connectionErrorListener;
listeners[WebSocketClient.listenerType.CONNECTION_UNACCEPTABLE] = connectionUnacceptableListener;
listeners[WebSocketClient.listenerType.SENDING_FAILURE] = eventSendingFailListener;
listeners[WebSocketClient.listenerType.SENDING_SUCCESS] = eventSendingSuccessListener;
listeners['/im/backend/service1'] = customlizedEvent1Listener;
listeners['/im/backend/service2'] = customlizedEvent2Listener;


const WebSocketConfig = {

    wsclient: null,

    init: function (token) {
        let that = this;
        WebSocketClient
            .create({
                proxy: 'http://www.sit1.bwoilmarine.com',
                serviceName: 'im',
                authorization: token,
                listeners: listeners,
                logging: false
            })
            .then(results => {
                console.log('creating websocket client succeed!');
                that.wsclient = results;
                that.connect();
            }, err => {
                console.log('creating websocket client failed due to ' + err);
            });
    },

    connect: function () {
        this.wsclient.connect().then(result => {
            console.log('setup connection done');
        }, err => {
            console.log('setup connection failed due to ' + err);
        });
    },

    send: function (msg) {
        if (!this.wsclient) {

        } else {
            console.log('调用send');
            this.wsclient.send(msg);
        }
    },

    getToken: function () {

        let temp = {
            "email": "gateway02@gmail.com",
            "password": "123456"
        };
        let that = this;
        RestClient.call(apiConfig.getToken, null, temp)
            .then(res => {
                if (res.status === 200) {
                    let {access_token: token} = res.data;
                    that.init(token);
                }
            });
    }
};


export default WebSocketConfig;