import WebSocketClient from 'bmo-websocket-client';
import apiConfig from '../services/apiConfig';
import {RestClient} from 'bmo-rest-client';
import  Listeners from './Listeners';
import  Configuration from './Configuration';

const WebSocketConfig = {
    wsclient: null,
    init: (token) => {
        WebSocketClient
            .create(Configuration.init(token ,Listeners))
            .then(results => {
                console.log('creating websocket client succeed!');
                WebSocketConfig.wsclient = results;
                WebSocketConfig.connect();
            }, err => {
                console.log('creating websocket client failed due to ' + err);
            });
    },

    connect: () => {
        WebSocketConfig.wsclient.connect().then(result => {
            console.log('setup connection done');
        }, err => {
            console.log('setup connection failed due to ' + err);
        });
    },

    send: (random,uri,body)=> {
        if(WebSocketConfig.wsclient){
           let message = [{'id': random, 'uri': uri, 'body': JSON.stringify(body)}];
            WebSocketConfig.wsclient.send(message);
         }else{
            console.log('client  connection failed');
        }
    },
    
    send: (msg) => {
        if (WebSocketConfig.wsclient) {
            WebSocketConfig.wsclient.send(msg);
        } else {
            console.log('client  connection failed');
        }
    },
    getToken:() =>{
        let temp = {
            "email": "tony.yang@bwoil.com",
            "password": "123456"
        };
        RestClient.call(apiConfig.login, null, temp)
            .then(res => {
                if (res.status === 200) {
                    let {access_token: token} = res.data;
                    WebSocketConfig.init(token);
                }
            });
    }
};


export default WebSocketConfig;