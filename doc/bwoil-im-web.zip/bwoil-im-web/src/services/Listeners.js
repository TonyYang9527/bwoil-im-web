import WebSocketClient from 'bmo-websocket-client';
import messageStore from '../stores/MessageStore' ;
import SessionStore from '../stores/SessionStore' ;
import UserStore from '../stores/UserStore' ;
import ContactStore from '../stores/ContactStore' ;
import WebSocketConfig from "./webSocketConfig";
import UUID from '../tools/UUID' ;
import Constant from '../tools/Constant';

const Listeners = { };
const openListener = () => {};
const errorListener = ({message}) => {
    console.log('CLIENT ERROR:',message);
};

const HEARTBEAT_ID = "THE_ID_OF_HEARTBEAT";

const connectedListener = ({status, message}) => {
    console.log('CLIENT CONNECTED:[' + status + ']');
    let heartbeat = [{
        "id": UUID.uuid(),
        "uri": "/im/user/online/heartbeat",
        "body": JSON.stringify({userId: UserStore.state.userId})
    }];
    setInterval(()=>{
        console.log('CLIENT SEND HEART BEAT :',heartbeat);
        WebSocketConfig.send(heartbeat);},60000);

     /*****system init
      let systemInit = [{
        "id": UUID.uuid(),
        "uri": "/im/system/init",
        "body": JSON.stringify({token: UserStore.state.token})
       }];
       WebSocketConfig.send(systemInit);
    ******/   

};
const disconnectedListener = () => {
    console.log('CLIENT DISCONNECTED');
};
const connectionErrorListener = ({status, message}) => {
    console.log('CLIENT CONNECTED FAILED:' + status ,message);
};
const connectionUnacceptableListener = ({status, message}) => {
    console.log('CLIENT UNACCEPTABLE:',status ,message );
};

/**Message send Fail Listener**/
const eventSendingFailListener = ({status, message, eventId}) => {
        switch (eventId){
               case HEARTBEAT_ID : 
                    console.log('HEARTBEAT SENDED FAILED:' );
                    break;
               default : 
                    console.log('CLIENT SENDED FAILED:',status, message,eventId );
         }
};
/**Message send Success Listener**/
const eventSendingSuccessListener = ({eventId}) => {
    switch (eventId){
           case HEARTBEAT_ID:
                console.log('HEARTBEAT SENDED SUCCESS:' );
                break;
           default:
                console.log('CLIENT SENDED SUCCESS:',eventId);
                messageStore.actions.updateMsgStatus(eventId,Constant.MSG_STATUS.SEND) ;    
        }
};

 /**backend  push message Listener **/
 const  eventChangeMessageListener= ({eventName, eventData}) => {
       console.log('MESSAGE CHANGE NOTIFY:',eventName ,eventData);
       //add new message & change message status 'read'
       messageStore.actions.addOrUpdateMessage(eventData.msgAddOrUpdata) ; 
};
 /**backend  push conversation Listener **/
const eventChangeConvsListener = ({eventName, eventData}) => {
     console.log('CONVERSATION CHANGE NOTIFY:',eventName,JSON.stringify(eventData));
      SessionStore.actions.changeConvs(eventData.covsAddOrUpdate);
};

 /**backend  push contact Listener **/
const eventChangeContactListener = ({eventName, eventData}) => {
    console.log('CONTACT  CHANGE  NOTIFY:', eventName ,JSON.stringify(eventData));
    ContactStore.actions.changeContact(eventData.contactAddOrUpdate);
};

 /**backend  push user states Listener **/
const eventUserStateListener = ({eventName, eventData}) => {
     console.log('USER STATE:', eventName ,JSON.stringify(eventData));
};

 /**backend  system init Listener **/
const eventSystemInitListener = ({eventName, eventData}) => {
        console.log('SYSTEM INIT :', eventName ,JSON.stringify(eventData));
        SessionStore.actions.init(eventData.convs);
        ContactStore.actions.init(eventData.contacts);
};
/**All Listener **/
Listeners[WebSocketClient.listenerType.OPEN] = openListener;
Listeners[WebSocketClient.listenerType.ERROR] = errorListener;
Listeners[WebSocketClient.listenerType.CONNECTED] = connectedListener;
Listeners[WebSocketClient.listenerType.DISCONNECTED] = disconnectedListener;
Listeners[WebSocketClient.listenerType.CONNECTION_ERROR] = connectionErrorListener;
Listeners[WebSocketClient.listenerType.CONNECTION_UNACCEPTABLE] = connectionUnacceptableListener;
Listeners[WebSocketClient.listenerType.SENDING_FAILURE] = eventSendingFailListener;
Listeners[WebSocketClient.listenerType.SENDING_SUCCESS] = eventSendingSuccessListener;
/**message Listener**/
Listeners['/im/message/add-update'] = eventChangeMessageListener;
/**conversation Listener**/
Listeners['/im/conversation/add-update'] = eventChangeConvsListener;
/**contact Listener**/
Listeners['/im/contact/add-update'] = eventChangeContactListener;
/**user Listener**/
Listeners['/im/user/state'] = eventUserStateListener;
/**system init Listener**/
Listeners['/im/init'] = eventSystemInitListener;

export default Listeners;