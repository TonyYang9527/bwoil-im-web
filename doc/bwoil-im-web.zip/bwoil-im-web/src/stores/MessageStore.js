import {observable, action, autorun} from 'mobx';
import {RestClient} from "bmo-rest-client";
import userStore from "./UserStore";
import apiConfig from "../services/apiConfig";

const data = observable({
    id: 0,
    messages: observable.map(),
    scrollbar: null,
    currentUserId : userStore.state.userId
});

const actions = {
    init: action((covnsId) => {
            data.id = covnsId;
            data.messages.clear();
            let {userId} = userStore.state;
            RestClient.call(apiConfig.messageList, null, {userId: userId, covsId: covnsId})
                .then(res => {
                    console.log("messageList res :" , res) ;
                     res.data.forEach(item =>{
                        data.messages.set(item.random, item);
                    });
                });
    }),

    addOrUpdateMessage: action((message) =>{
         data.messages.set(message.random, message);
         actions.scrollToBottom();
    }),

    updateMsgStatus: (random,status) =>{
        if( data.messages.has(random)){
            data.messages.get(random).messageStatus = status ;
        }
   },
    getScrollbar: action((ref) => {
        if (!data.scrollbar) {
            data.scrollbar = ref;
        }
    }),

    scrollToBottom: action(() => {
        if (data.scrollbar) {
            data.scrollbar.scrollToBottom();
        }
    }) 
};

autorun(() => {
    if (data.scrollbar) {
        data.scrollbar.scrollToBottom();
    }
});

export default {data, actions};