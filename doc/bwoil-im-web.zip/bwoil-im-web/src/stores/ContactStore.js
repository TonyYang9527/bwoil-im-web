import {observable, action, autorun} from 'mobx';

import sessionStore from './SessionStore';
import {contacts} from '../mock/Data';

const data = observable({
    contacts: observable.map()
});

const actions = {
    init: action((contacts) => {
        contacts.forEach((elem) => {
            data.contacts.set(elem.id, elem);
        });
    }),
    add: action((contact) => {
        if (!data.contacts.has(contact.id)) {
            data.contacts.set(contact.id, contact);
        }
    }),
    rename: action((id, name) => {
        if (data.contacts.has(id)) {
            data.contacts.get(id).name = name;
        }
    }),
    delete: action((id) => {
        if (data.contacts.has(id)) {
            data.contacts.delete(id);
        }
    })
};

autorun(() => {
    if (!data.contacts.size) {
        actions.init(contacts);
    }
});

export default {data, actions};