import {observable, action, when} from 'mobx';
import {RestClient} from 'bmo-rest-client';
import apiConfig from '../services/apiConfig';
import userStore from '../stores/UserStore';


const data = observable({
    contacts: observable.map()
});

const actions = {
    init: action((contacts) => {
        contacts.forEach(item => {
            item.id = `${item.contactId}`;
            data.contacts.set(item.id, item);
        });
    }),
    add: (contact) => {
        if (!data.contacts.has(contact.id)) {
            data.contacts.set(contact.id, contact);
        }
    },
    rename: action((id, name) => {
        if (data.contacts.has(id)) {
            data.contacts.get(id).name = name;
        }
    }),
    delete: action((id) => {
        if (data.contacts.has(id)) {
            data.contacts.delete(id);
        }
    }),
    
    changeContact:action((contact) => {
         state.contacts.set(contacts.contactId, contacts);
      }),

};

when(
    () => !data.contacts.size,
    () => {
          let userId = userStore.state.userId;
           RestClient.call(apiConfig.contactList,{userId:userId},null)
            .then(res => {
                if (res.status ===200 && res.data) {
                    actions.init(res.data);
                }
            });
    }
);

export default {data, actions};