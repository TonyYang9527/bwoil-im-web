import {observable, action, autorun, when} from 'mobx';

import globalStore from './GlobalStore';
import messageStore from './MessageStore';
import conversationStore from './ConversationStore';
import profileStore from './ProfileStore';
import addContactStore from './AddContactStore';
import partnerStore from './PartnerStore';
import {RestClient} from 'bmo-rest-client';
import apiConfig from '../services/apiConfig';
import userStore from '../stores/UserStore';
import SessionUtil from '../utils/SessionUtil';

const state = observable({
    sessions: observable.map(),
    selected: {},
    copy: {}
});

const actions = {
    init: action((sessions) => {
        /**TODO: please call init api**/
        sessions.forEach((item) => {
            console.log('conversation', item);
            item.id = `${item.id}`;
            item.status = SessionUtil.getStatus(item.states);
            item.time = SessionUtil.getLocalTime(item.updateTime);
            item.className = "conversation";
            item.modalVisible = false;
            state.sessions.set(item.id, item);
        });
    }),

    select: action((id) => {
        if (state.sessions.has(id)) {
            state.selected = state.sessions.get(id);
            state.selected.unread = 0;
            actions.changeStyle(id);

            /**TODO: please call other api**/
            messageStore.actions.init(id);
            conversationStore.actions.init(id);
            profileStore.actions.init(id);
        }
        globalStore.actions.restoreTab();
    }),

    add: action((contact) => {
        /**TODO: please call add api**/
        let {userId, name} = userStore.state;
        let userIds = [userId, contact.contactId];
        let names = `${name},${contact.contactName}`;
        let temp = {userId: userId, name: names, userIds: userIds};
        RestClient.call(apiConfig.covsAdd, null, temp)
            .then(res => {
                let {data} = res.data;
                console.log('add返回数据', data);
                data.status = SessionUtil.getStatus(data.states);
                data.time = SessionUtil.getLocalTime(data.updateTime);
                data.className = "conversation";
                data.modalVisible = false;
                state.sessions.set(data.id, data);
                actions.changeStyle(data.id);
                globalStore.actions.restoreTab();
            });
    }),

    onOk: action((opt, covsId) => {
        if (opt === "1") { //delete conversation
            let {userId} = userStore.state;
            let temp = {userId: userId, covsIds: [covsId]};
            RestClient.call(apiConfig.covsDelete, null, temp)
                .then(res => {
                    let {result} = res.data;
                    if (result) {
                        state.sessions.delete(covsId);
                    }
                });
            /**TODO: please call delete api**/
        } else if (opt === "2") { //rename conversation
            /**TODO: please call rename api**/
            if (state.sessions.get(covsId).name !== state.copy.name) {
                let {userId} = userStore.state;
                let {name, users} = state.sessions.get(covsId);
                let temp = {userId: userId, covsId: covsId, name: name, userIds: users};
                RestClient.call(apiConfig.covsUpdate, null, temp)
                    .then(res => {
                        let {data} = res;
                        if (data.result) {
                            let {id, name} = data.data;
                            state.sessions.get(id).name = name;
                        }
                        state.sessions.get(covsId).modalVisible = false;
                    });
            } else {
                state.sessions.get(covsId).modalVisible = false;
            }
        } else if (opt === "3") { //exit  conversation
            /**TODO: please call exit api**/
            let {userId} = userStore.state;
            let {users} = state.sessions.get(covsId);
            let tempUsers = users.filter(elem => elem !== userId);
            let temp = {userId: userId, covsId: covsId, userIds: tempUsers};
            RestClient.call(apiConfig.covsUpdate, null, temp)
                .then(res => {
                    let {id, users} = res.data.data;
                    let contain = users ? users.some(elem => elem === userId) : false;
                    if (!contain) {
                        state.sessions.delete(id);
                    }
                });
        }
    }),

    onCancel: action((opt, id) => {
        if (opt === "2") {
            state.sessions.get(id).name = state.copy.name;
            state.sessions.get(id).modalVisible = false;
        } else if (opt === "1" || opt === "3") {
            state.sessions.get(id).modalVisible = false;
        } else {
            //  do  nothing
        }
    }),

    dropdown: action((key, session) => {
        session.modalVisible = true;
        session.opt = key;
        state.copy = {id: session.id, opt: key, name: session.name};
    }),

    addContact: action((id, preAdd) => {
        /**TODO: please call invite  api**/
        let {userId} = userStore.state;
        let {name, users} = state.selected;
        let userIds = users.concat(preAdd.map(elem => elem.id));
        let temp = {userId: userId, covsId: id, name: name, userIds: userIds};
        RestClient.call(apiConfig.covsUpdate, null, temp)
            .then(res => {
                console.log(res.data);
                let {data} = res.data;
                data.status = SessionUtil.getStatus(data.states);
                data.time = SessionUtil.getLocalTime(data.updateTime);
                data.className = "conversation conversation-focused";
                data.modalVisible = false;
                state.sessions.set(data.id, data);
                state.selected = state.sessions.get(id);
                addContactStore.actions.closeModal();
            });
    }),

    changeStyle: action((id) => {
        state.sessions.forEach((value, key, map) => {
            if (key === id) {
                value.className = 'conversation conversation-focused';
            } else {
                value.className = 'conversation';
            }
        });
    }),
};

when(
    () => !state.sessions.size,
    () => {
        let {userId} = userStore.state;
        let temp = {userId: userId};
        RestClient.call(apiConfig.covsList, null, temp)
            .then(res => {
                let {data = []} = res.data;
                actions.init(data);
            });
    }
);

autorun(() => {
    if (state.selected.partners) {
        partnerStore.actions.closeModal();
    }
});

export default {state, actions};