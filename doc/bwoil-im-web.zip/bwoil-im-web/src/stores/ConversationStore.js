import {observable, action, autorun, when} from 'mobx';
import messageStore from './MessageStore';
import userStore from './UserStore'
import WebSocketConfig from '../services/webSocketConfig';
import UUID from '../tools/UUID' ;
import MessageBuilder from '../builder/MessageBuilder' ;

const data = observable({
    id: 0,
    textArea: null,
    text: '',
});

const actions = {
    init: action((id) => {
        if (data.id !== id) {
            data.id = `${id}`;
            data.text = '';
        }
    }),
    onFocus: action((e) => {
        if (!data.textArea) {
            data.textArea = e.target;
        }
    }),
    onChange: action((e) => {
        data.text = e.target.value;
    }),

    sendMessage: action((e) => {
        e.preventDefault();
        let random =UUID.uuid() ;
        let body =[{"covsId":messageStore.data.id,"msgContent": data.text,"senderId": userStore.state.userId,"msgType": 1 ,'random' :random}];
        let message = [{ 'id': random, 'uri': '/im/message/add', 'body': JSON.stringify(body)}];
        console.log("messages ", message) ;
        WebSocketConfig.send(message);
         data.text = '' ;   
        let msgData = MessageBuilder.transform(messageStore.data.id,1,data.text,random) ;
       // messageStore.actions.addOrUpdateMessage(message) ;
        messageStore.actions.scrollToBottom();
    })
};

when(
    () => !data.textArea,
    () => {
        WebSocketConfig.getToken();
    }
);

autorun(() => {
    if (data.text) {
        if (data.textArea.scrollHeight > data.textArea.clientHeight) {
            if (!data.textArea.classList.contains('with-scrollbar')) {
                data.textArea.classList.add('with-scrollbar');
            }
        } else {
            if (data.textArea.classList.contains('with-scrollbar')) {
                data.textArea.classList.remove('with-scrollbar');
            }
        }
    } else {
        if (data.textArea) {
            data.textArea.focus();
        }
        messageStore.actions.scrollToBottom();
    }
});

export default {data, actions};