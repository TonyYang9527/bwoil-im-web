import {observable, action, autorun, when} from 'mobx';
import messageStore from './MessageStore';
import userStore from './UserStore'
import WebSocketConfig from '../services/webSocketConfig';
import apiConfig from "../services/apiConfig";
import {RestClient} from "bmo-rest-client";
import MessageUtil from "../utils/MessageUtil";

const data = observable({
    id: 0,
    textArea: null,
    text: '',
});

const actions = {
    init: action((id) => {
        if (data.id !== id) {
            data.id = `${id}`;
            data.text = '';
        }
    }),
    onFocus: action((e) => {
        if (!data.textArea) {
            data.textArea = e.target;
        }
    }),
    onChange: action((e) => {
        data.text = e.target.value;
    }),
    sendMessage: action((e) => {
        e.preventDefault();
        // if (data.text) {
        //     let message = {
        //         id: 101,
        //         avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        //         type: "text",
        //         message: data.text,
        //         status: "sent",
        //         time: "02:49",
        //         fromUser: true
        //     };
        //     data.text = '';
        //     messageStore.actions.addMessage(message);
        // }
        // 'http://www.sit1.bwoilmarine.com/api/im/message/add'
        // "{"action":2,"status":200,"dataId":"194563886551138306"}"
        if (data.text) {
            let msg = [{
                'id': '10001',
                'uri': 'im/message/add',
                'body': {
                    "msgItems": [
                        {
                            "conversationId": data.id,
                            "msgDetail": data.text,
                            "senderId": userStore.state.userId,
                            "type": 1
                        }
                    ]
                }
            }];
            WebSocketConfig.send(msg);
            data.text = '';
            // let temp = {userId: '987654321123456789', covsId: '193405258154639362'};
            // RestClient.call(apiConfig.messageList, null, temp)
            //     .then(res => {
            //         let {data: messages} = res.data;
            //         console.log(messages[0].msgDetail);
            //     });
        }
    })
};

when(
    () => !data.textArea,
    () => {
        WebSocketConfig.getToken();
    }
);


autorun(() => {
    if (data.text) {
        if (data.textArea.scrollHeight > data.textArea.clientHeight) {
            if (!data.textArea.classList.contains('with-scrollbar')) {
                data.textArea.classList.add('with-scrollbar');
            }
        } else {
            if (data.textArea.classList.contains('with-scrollbar')) {
                data.textArea.classList.remove('with-scrollbar');
            }
        }
    } else {
        if (data.textArea) {
            data.textArea.focus();
        }
        messageStore.actions.scrollToBottom();
    }
});

export default {data, actions};