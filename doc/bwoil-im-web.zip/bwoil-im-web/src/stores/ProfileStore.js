import {observable, action} from 'mobx';

import {cargo,vessel} from "../mock/Data";

const state = observable({
     vessel: null,
     cargo :null,
});

const actions = {
    init: action((id) => {
    /**TODO: restClient load vessel&cargo Request **/
     state.cargo=cargo;
     state.vessel=vessel;
    }),

    clear: () => {
        state.cargo=null;
        state.vessel=null;
    }
};

export default {state, actions};