import {observable, action} from 'mobx';

const state = observable({
    userId: '987654321123456789',
    name: 'Karl'
});

const actions = {
    setUserId: action((id) => {
        state.userId = id;
    })
};

export default {state, actions}