import {observable, action} from 'mobx';
import {RestClient} from "bmo-rest-client";
import apiConfig from "../services/apiConfig";
import WebSocketConfig from '../services/webSocketConfig';
import Constant from "../tools/apiConfig";

const  state = observable({
        email: '' ,
        password :'' ,
        token : '',
        userId: '194864903125730329',
        loginSuccee: false ,
        Users: observable.map(),
  });

const actions = {
     setUserId: action((id) => {
         state.userId = id;
     }),
     
    queryUers: action((userIds) => {
          let result = '' ;
          RestClient.call(apiConfig.getUsers,null,userIds).then(res=>result=res.data); 
         return result ;
    }),

    getUerStatus: action((userId) => {
         return state.Users.has(userId) ? state.Users.get(userId):Constant.USER_STATUS.OFFLINE;
    }),

    loadUsers:(users) => {
        if(users){  
           users.forEach(user =>state.Users.set(user.id, user));
        }   
    },

    login:action(()=>{
           RestClient.call(apiConfig.login, null,{"email":state.email,"password": state.password})
            .then(res => {
                if(res.status === 200 && res.data ){
                   state.token = res.data.access_token;
                   loginSuccee =true;
                }
            });  
          WebSocketConfig.init(state.token);
      })
};

export default {state, actions}