import {observable, action} from 'mobx';

const state = observable({
    modalShow: false
});

const actions = {
    openModal: action(() => {
        state.modalShow = true;
    }),
    closeModal: action(() => {
        state.modalShow = false;
    }),
    upDown: action(() => {
        state.modalShow = !state.modalShow;
    }),
    reset: action(() => {
        state.modalShow = false;
    }),
    

};

export default {state, actions};

