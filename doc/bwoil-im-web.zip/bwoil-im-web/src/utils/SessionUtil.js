const months = {
    '0': 'Jan', '1': 'Feb', '2': 'Mar', '3': 'Apr', '4': 'May', '5': 'Jun',
    '6': 'Jul', '7': 'Aug', '8': 'Sep', '9': 'Oct', '10': 'Nov', '11': 'Dec'
};

const statusList = {'0': 'default', '1': 'success', '2': 'error'};


const SessionUtil = {

    getStatus: (state) => {
        return statusList[state] ? statusList[state] : statusList[0];
    },

    getLocalTime: (time) => {
        if (time) {
            let date = new Date(time);
            let now = new Date();
            if (date.toDateString() === now.toDateString()) {
                let hour = date.getHours() > 9 ? date.getHours() : `0${date.getHours()}`;
                let minute = date.getMinutes() > 9 ? date.getMinutes() : `0${date.getMinutes()}`;
                return `${hour}:${minute}`;
            }
            return `${date.getDate()} ${months[date.getMonth()]}`;
        } else {
            return '';
        }
    }
};

export default SessionUtil;