import React from 'react';
import {observer} from 'mobx-react';
import {Icon, Input} from 'antd';
import './Search.less';

import globalStore from '../../stores/GlobalStore';



const prefix = <Icon type="search"/>;

const Suffix = observer((props)=>{
    if(!props.filter){
        return  null; 
    }
    return ( <Icon type="close-circle" onClick={props.clearUp}/>);
  });


const Search = observer(() => {
        const suffix =<Suffix  filter={globalStore.data.filter}  clearUp={globalStore.actions.clearFilter} />
        return (
            <div className='search'>
                <Input size="large" style={{fontSize: 14, background: '#EFEFEF', borderRadius: 4}}
                       placeholder='Search contact…'
                       value={globalStore.data.filter}
                       prefix={prefix}
                       suffix={suffix}
                       onChange={globalStore.actions.changeFilter}/>
            </div>
        );
    }
);

export default Search;