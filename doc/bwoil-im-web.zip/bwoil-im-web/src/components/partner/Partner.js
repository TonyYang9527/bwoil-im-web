import React from 'react';
import {observer} from 'mobx-react';
import {Scrollbars} from 'react-custom-scrollbars';
import {Avatar} from 'antd';
import './Partner.less';

import sessionStore from '../../stores/SessionStore';
import contactStore from '../../stores/ContactStore';
import partnerStore from '../../stores/PartnerStore';

const Partner = observer(() => {
    let {state} = sessionStore;
    let {data} = contactStore;

    let length = 0;
    if (!partnerStore.state.modalShow || !state.selected.partners) {
        return null;
    }
    length = Math.ceil(state.selected.partners.length/ 2);

    let temp = [];
    if (length > 0) {
        for (let i = 0; i < length; i++) {
            if (i !== length - 1) {
                temp.push([state.selected.partners[i * 2], state.selected.partners[i * 2 + 1]]);
            } else {
                if (state.selected.partners.length % 2 === 0) {
                    temp.push([state.selected.partners[i * 2], state.selected.partners[i * 2 + 1]]);
                } else {
                    temp.push([state.selected.partners[i * 2]]);
                }
            }
        }
    }
    console.log(length);

    let height = length > 5 ? 256 : 16 + 48 * length;

    return (

        <div className='partner'>
            <Scrollbars style={{width: 480, height: height}}
                        renderThumbVertical={renderThumbVertical}
                        renderThumbHorizontal={renderThumbHorizontal}
                        thumbSize={56}>
                {
                    temp.map((elem, index) => {
                        return (
                            <div className='partner-row' key={index}>
                            <span className='offline'>
                                <Avatar src={data.contacts.get(elem[0]).image}/>
                                <span>
                                    {data.contacts.get(elem[0]).name}
                                </span>
                            </span>
                                {
                                    elem[1] ? <span className='online'>
                                <Avatar src={data.contacts.get(elem[1]).image}/>
                                <span>
                                   {data.contacts.get(elem[1]).name}
                                </span>
                            </span> : null
                                }
                            </div>
                        )
                    })
                }
            </Scrollbars>
        </div>
    );
});

const renderThumbVertical = function ({style, ...props}) {
    const thumbStyle = {backgroundColor: '#5F5F5F', width: 4, right: -4};
    return (<div style={{...style, ...thumbStyle}} {...props} />);
};

const renderThumbHorizontal = function ({style, ...props}) {
    const thumbStyle = {visibility: 'hidden'};
    return (<div style={{...style, ...thumbStyle}} {...props} />);
};

export default Partner;