import React from 'react';
import {Scrollbars} from 'react-custom-scrollbars';


var self = null;
/*****TODO:  need good solution to remove  styleDefault, auto-get children heigth & width **/
const styleDefault = {width: 250, height: 572} ;

/****Horizontal***/
const renderThumbHorizontal =({style, ...props}) => {
    const thumbStyle = {backgroundColor: '#5F5F5F', width: 4, right: -4};
    return (<div style={{...style, ...thumbStyle}} {...props} />);
};

/****Vertical***/
const renderThumbVertical =({style, ...props})=> {
    const thumbStyle = {visibility: 'hidden'};
    return (<div style={{...style, ...thumbStyle}} {...props} />);
};

const BwoilScrollbars = (props) => {
    const cust_props = {
        style:props.style?props.style:styleDefault,
        renderThumbHorizontal: renderThumbHorizontal ,
        renderThumbVertical:   renderThumbVertical,
        thumbSize: 56
    };
  return (
         <Scrollbars ref={scrollbar => self = scrollbar} {...cust_props} >
             {props.children}
         </Scrollbars>
       );
};
export default BwoilScrollbars;