import React from 'react';
import { observer } from "mobx-react";
import BwoilScrollbars from "../../scrollbars/Scrollbars";
import Message from '../../message/index' ;
import './messages.less';

const Messages = observer((props) => {
    let getScrollbar = props.getScrollbar;
    return (
        <div style={{ width: 480, height: 476 }}>
            <BwoilScrollbars getRef={getScrollbar}>
                {props.messages.map((item, index) => <Message message={item} key={index}  current={props.current}  />)}
            </BwoilScrollbars>
        </div>
    );
});
export default Messages;