import React from 'react';
import {observer} from 'mobx-react';
import {Avatar, Row, Col} from 'antd';
import BwoilScrollbars from '../../../components/scrollbars/Scrollbars';
import './members.less';

const MemberItem = (props) => {
    let {members} = props;
    return (
        <Row gutter={16}>
            {members.map((elem, index) => {
                return (
                    <Col span={4} key={index}>
                        <div>
                            <Badge dot  status={props.contact.status}  offset={[29,-2]}>
                                <Avatar  shape="square" src={process.env.PUBLIC_URL.concat("/assets/icon/user/").concat(elem.icon)} />
                            </Badge>
                            <p title={elem.name}>{elem.name}</p>
                        </div>
                    </Col>
                )
            })}
        </Row>
    );
};

const BoxMembers = observer((props) => {
    let {members = [], visable} = props;
    if (!visable) {
        return null;
    }
     console.log("selected" ,  props.selected()) ;
    members = members.map(elem => {
        return {
            memberId: elem,
            name: 'Robust China-UK "golden era" relations have entered a new stage',
            icon: process.env.PUBLIC_URL.concat("/assets/icon/user/captain.png")
        };
    });

    return (
        <div className='partner'>
            <BwoilScrollbars>
                <MemberItem members={members}/>
            </BwoilScrollbars>
        </div>
    );
});

export default BoxMembers;