import React from 'react';
import { observer } from "mobx-react";
import ImageMsg from '../category/image-message/ImageMsg' ;
import TextMsg from '../category/text-message/TextMsg';
import OfferMsg from '../category/offer-message/OfferMsg';
import AttachMsg from '../category/attach-message/AttachMsg';

const MsgWrapper = observer((props) => {
    
    if (props.message.type === "text") {
        return ( <TextMsg message={props.message}  />) ;
    } else if (props.message.type === "image") {
        return ( <ImageMsg message={props.message} />);
    } else if (props.message.type === "sub") {
        return ( <OfferMsg message={props.message} />);
    } else if (props.message.type === "pdf" ||props.message.type === "doc"
             ||props.message.type === "txt"||props.message.type === "xls"
             ||props.message.type === "ppt") {
        return ( <AttachMsg message={props.message} />);    
    } else {
        return null;
    }
});
export default MsgWrapper;