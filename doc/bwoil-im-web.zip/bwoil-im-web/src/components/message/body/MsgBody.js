import React from 'react';
import {observer} from "mobx-react";
import MsgNotes from '../notes/MsgNotes' ;
import MsgBubble from '../bubble/MsgBubble' ;


const GroupMsgBody = observer((props) => {
    return (
        <div className="msgcontent">
            <h4 className="nickname">{props.message.sender}</h4>
            <MsgBubble message={props.message} className={props.className}/>
            <div className="msgstatus"><MsgNotes message={props.message}/></div>
        </div>
    );
});

const UserMsagBody = observer((props) => {
    return (
        <div className="msgcontent">
            <MsgBubble message={props.message} className={props.className}/>
            <MsgNotes message={props.message}/>
        </div>
    );
});

export {GroupMsgBody, UserMsagBody};
