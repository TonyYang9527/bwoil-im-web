import React from 'react';
import { observer } from "mobx-react";
import  {UserMsagBody} from  './body/MsgBody' ;
import {UserImgAvatar}  from  './avatar/UserAvatar' ;
import './index.less';

/****
 * TEXT :
 *   right: bubble bubble_primary right
 *   left: bubble bubble_default left
 * IMAGE :
 *   right: bubble bubble_primary_image right
 *   left:  bubble bubble_default_image left
 * ******/
const Message = observer((props) => {
    let msgOwner = false ;
    let bubble = "" ;
    if(props.current ===props.message.senderId){
        msgOwner=true ;
     }
    let className =  msgOwner ? 'message  me' : 'message  you';
    if(props.message.type===1) {
       bubble =msgOwner ? 'bubble bubble_primary right' : 'bubble bubble_default left';
    }else if (props.message.type==="image") {
       bubble =msgOwner ? 'bubble bubble_primary_image right' : 'bubble bubble_default_image left';
    } else if(props.message.type === "pdf" ||props.message.type === "doc"
    ||props.message.type === "txt"||props.message.type === "xls" 
    ||props.message.type === "ppt") 
    {
        bubble =msgOwner ? 'bubble bubble_primary_attach right' : 'bubble bubble_default_attach left';   
    } else{
       bubble =msgOwner ? 'bubble bubble_primary right' : 'bubble bubble_default left'; 
    }
   return (
       <div className={className} >
         <UserImgAvatar message={props.message}/>
         <UserMsagBody message={props.message} className={bubble} />
       </div>
   );
});

export default Message;