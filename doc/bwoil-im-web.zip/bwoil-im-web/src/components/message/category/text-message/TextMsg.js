import React from 'react';
import {observer} from "mobx-react";
import './textMsg.less';

const TextMessage = observer((props) => {
    return (
            <div className="text-message">
                <span className="text-message-content" >{props.message.msgDetail} </span>
             </div>
           );
});
export default TextMessage;