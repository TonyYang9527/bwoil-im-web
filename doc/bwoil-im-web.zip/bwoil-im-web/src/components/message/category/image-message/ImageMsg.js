import React from 'react';
import {observer} from "mobx-react";
import {Icon} from 'antd';
import ImagePreview from  './preview/ImagePreview' ;
import './imageMsg.less';


const ImageMsg = observer((props) => {
        const preView =(e)=>{
            props.message.visible=true ;
            e.stopPropagation();
        };
       const download = (e) => {
          e.stopPropagation();
         };
        return (
        <div className="preview-image-picture-card"> 
            <div className="preview-image-item">
                <div className="preview-image-item-info" >
                     <span>
                            <a className="preview-image-item-thumbnail" href={props.message.msgDetail}    target="_blank" >  
                                <img src={props.message.msgDetail} alt='xxx.png'/>
                            </a> 
                     </span>
                </div>
                <span className="preview-image-item-actions">
                     <Icon title="preview" type='eye-o' onClick={preView} />
                     <Icon title="download" type='cloud-download' onClick={download} />
                </span>
                <ImagePreview message={props.message} />
            </div>
       </div>);
    });
export default ImageMsg;