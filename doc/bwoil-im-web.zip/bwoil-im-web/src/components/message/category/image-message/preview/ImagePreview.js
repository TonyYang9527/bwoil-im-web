import React from 'react';
import {observer} from "mobx-react";
import {Modal} from 'antd';
import './imagePreview.less';

const ImagePreview = observer((props) => {
    const onCancel = (e) => {
        props.message.visible=false ;
        e.stopPropagation();
    };
    return (
        <Modal visible={props.message.visible} footer={null} onCancel={onCancel}>
            <img alt="example" style={{width: '100%', heigth: '100%'}} src={props.message.message}/>
        </Modal>
    );
});
export default ImagePreview;