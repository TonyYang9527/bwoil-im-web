import React from 'react';
import {observer} from "mobx-react";
import {Icon} from 'antd';
import './attachMsg.less';

const  attachIcon = (type) => {
    let attach = "" ;
    if(type ==="doc"){
      attach =process.env.PUBLIC_URL.concat("/assets/icon/message/doc.png") ;
    } else if(type ==="pdf"){
      attach =process.env.PUBLIC_URL.concat("/assets/icon/message/pdf.png") ;
    } else if(type ==="txt"){
      attach =process.env.PUBLIC_URL.concat("/assets/icon/message/txt.png") ;
    } else if(type ==="xls"){
      attach =process.env.PUBLIC_URL.concat("/assets/icon/message/xls.png") ;    
    } else if(type ==="ppt"){   
      attach =process.env.PUBLIC_URL.concat("/assets/icon/message/ppt.png") ; 
    }
    return attach ;
};

const AttachMsg = observer((props) => {
     
       const download = (e) => {
          console.log("download onCilck ");
          e.stopPropagation();
         };

        return (
        <div className="attach-image-picture-card"> 
            <div className="attach-image-item">
                <div className="attach-image-item-info" >
                     <span>
                            <a className="attach-image-item-thumbnail" href={props.message.message}  target="_blank" >  
                                <img src={attachIcon(props.message.type)} alt='xxx.png'/>
                            </a> 
                     </span>
                </div>
                <span className="attach-image-item-actions">
                     <Icon title="download" type='cloud-download' onClick={download} />
                </span>
            </div>
       </div>);
    });
export default AttachMsg;