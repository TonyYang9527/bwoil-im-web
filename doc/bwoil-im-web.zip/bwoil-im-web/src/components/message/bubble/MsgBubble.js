import React from 'react';
import { observer } from "mobx-react";
import MsgWrapper from '../wrapper/MsgWrapper' ;
/****
 * TEXT :
 *   right: bubble bubble_primary right
 *   left: bubble bubble_default left
 * IMAGE :
 *   right: bubble bubble_primary_image right
 *   left:  bubble bubble_default_image left
 * ******/
const MsgBubble = observer((props) => {
    return (
             <div className={props.className}>
                <div className="bubble_cont">
                   <MsgWrapper  message={props.message}/>
                </div> 
             </div>
           );
});
export default MsgBubble;