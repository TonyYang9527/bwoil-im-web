import React from 'react';
import {observer} from 'mobx-react';
import {Icon} from 'antd';
import './ContentTitle.less';

import sessionStore from '../../stores/SessionStore';
import addContactStore from '../../stores/AddContactStore';
import partnerStore from '../../stores/PartnerStore';

const ContentTitle = observer(() => {

    let {state} = sessionStore;
    let name = state.selected.name ? state.selected.name : '';
    let count = state.selected.partners ? '(' + state.selected.partners.length + ')' : '';
    let icon = partnerStore.state.modalShow ?
        <Icon type='up' style={{marginLeft: 6}} onClick={partnerStore.actions.closeModal}/> :
        <Icon type='down' style={{marginLeft: 6}} onClick={partnerStore.actions.openModal}/>;
    return (
        <div className='content-title'>
            <span> {name + ' ' + count}
                {icon}
            </span>
            <Icon type='user-add' onClick={() => addContactStore.actions.openModal(1)}/>
        </div>
    );
});

export default ContentTitle;