import React from 'react';
import {observer} from 'mobx-react';
import Search from '../search/Search';
import {Tabs} from 'antd';
import {ConvsnList } from '../conversation/index';
import {ContactList} from '../contact/index';
import globalStore from '../../stores/GlobalStore';
import SessionStore from '../../stores/SessionStore';
import './Slider.less' ;

const SliderContainer = observer(() => {
    return (
        <div className="slider">
         <Search />
         <Tabs activeKey={globalStore.data.tabKey} onChange={globalStore.actions.changeTab}>
            <Tabs.TabPane tab='Message' key='1'>
               <ConvsnList conversations ={globalStore.data.filterSessions} actions={SessionStore.actions} />
            </Tabs.TabPane>
            <Tabs.TabPane tab='Contact' key='2'>
                <ContactList contacts ={globalStore.data.filterContacts} addSession={SessionStore.actions.add} />
            </Tabs.TabPane>
         </Tabs>
        
         </div>
    );
});

export default SliderContainer ;
