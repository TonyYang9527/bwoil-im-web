import React from 'react';
import {observer} from 'mobx-react';
import Partner from '../partner/Partner';
import ContentTitle from '../contentTitle/ContentTitle';
import MessagesBox from '../messagesBox/MessagesBox';
import TextBox from '../textBox/TextBox';
import sessionStore from '../../stores/SessionStore';
import './Content.less';

const ContentContainer = observer(() => {
    return (
        sessionStore.state.selected ?
            <div className='content'>
                <Partner/>
                <ContentTitle/>
                <MessagesBox/>
                <TextBox/>
            </div> : <div className='content'/>
    );
});

export {ContentContainer};
