import React from 'react';
import {observer} from 'mobx-react';
import Members from '../chat-box/members/Members';
import Header from '../chat-box/header/Header';
import Typing from '../chat-box/typing/Typing';
import Messages from '../chat-box/messages/Messages';
import sessionStore from '../../stores/SessionStore';
import messageStore from '../../stores/MessageStore';
import addContactStore from '../../stores/AddContactStore';
import partnerStore from '../../stores/PartnerStore';

import './Content.less';

const ContentContainer = observer(() => {

    if (!sessionStore.state.selected) {
        return <div className='content'/>;
    }
    let name = sessionStore.state.selected.name ? sessionStore.state.selected.name : '';
    let count = sessionStore.state.selected.memberIds ? '(' + sessionStore.state.selected.memberIds.length + ')' : '';
    return (
        <div className='content'>
            <Members selected ={sessionStore.actions.getSelected}  members={sessionStore.state.selected.memberIds} visable={partnerStore.state.modalShow}/>
            <Header name={name} count={count}
                    modalShow={partnerStore.state.modalShow}
                    upDown={partnerStore.actions.upDown}
                    openModal={() => addContactStore.actions.openModal(sessionStore.state.selected.id)}/>
            <Messages messages={messageStore.data.messages.values()}  current={messageStore.data.currentUserId}  
            getScrollbar={messageStore.actions.getScrollbar} />
            <Typing/>
        </div>
    );
});

export default ContentContainer;
