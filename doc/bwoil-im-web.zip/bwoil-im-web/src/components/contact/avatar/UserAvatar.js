import React from 'react';
import {observer} from 'mobx-react';
import {Avatar,Badge} from 'antd';

const UserAvatar =observer((props) => {
    return (
        <Badge dot  status={props.contact.status}  offset={[29,-2]}>
          <Avatar  style={{backgroundColor:'#00a2ae'}} icon="user" />
        </Badge>
    );
}) ;
export default UserAvatar;