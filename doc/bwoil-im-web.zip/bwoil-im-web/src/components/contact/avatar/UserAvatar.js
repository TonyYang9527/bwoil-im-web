import React from 'react';
import {observer} from 'mobx-react';
import {Avatar,Badge} from 'antd';


const UserAvatar =observer((props) => {
    let icon  = props.contact.icon?props.contact.icon:"ironman.png" ;
    return (
        <Badge dot  status={props.contact.status}  offset={[29,-2]}>
            <Avatar src={process.env.PUBLIC_URL.concat("/assets/icon/user/").concat(icon)} />
        </Badge>
    );
});
export default UserAvatar;