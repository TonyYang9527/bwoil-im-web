import React from 'react';
import {observer} from 'mobx-react';
import {Badge} from 'antd';



const Panels = observer((props) => {
    let unreadMsg = props.session.unreadMsg ; 
    let newMsg    = props.session.newMsg ;
    return (
        <div>
            <span>
                <span> {props.session.name}</span>
                <Badge count={ unreadMsg?unreadMsg.length:0} overflowCount={99} />
            </span>
            <span>{newMsg?newMsg.sendTimeStr:''}</span>
        </div>
    );
});

export default Panels;