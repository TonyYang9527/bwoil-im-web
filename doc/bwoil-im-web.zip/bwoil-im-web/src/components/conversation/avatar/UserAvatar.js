import React from 'react';
import {observer} from 'mobx-react';
import {Avatar, Badge} from 'antd';

const icons = new Map([[1, "antman.png"], [2, "atom.png"], [3, "batmen.png"], [4, "captain.png"], [5, "flash.png"],
    [6, "greenman.png"], [7, "hulk.png"], [8, "ironman.png"], [9, "spider.png"], [10, "superman.png"],
    [11, "thor.png"], [12, "wolverine.png"]
]);

const GAvatar = (props) => {
    return (<Avatar src={process.env.PUBLIC_URL.concat("/assets/icon/user/group.png")}/>);
};

const UAvatar = (props) => {
    let icon = icons.get(Math.floor(Math.random() * 12) + 1);
    return (
        <Badge dot status={props.session.status} offset={[29, -2]}>
            <Avatar src={process.env.PUBLIC_URL.concat("/assets/icon/user/").concat(icon)}/>
        </Badge>
    );
};

const UserAvatar = observer((props) => {
    const members = props.session.users.length;
    return (members > 2 ? <GAvatar/> : <UAvatar session={props.session}/>);
});

export default UserAvatar;