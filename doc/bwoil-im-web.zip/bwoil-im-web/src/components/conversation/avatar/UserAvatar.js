import React from 'react';
import {observer} from 'mobx-react';
import {Avatar, Badge} from 'antd';

const states = new Map([[1, "success"], [2, ""], [3, ""]]);

const GAvatar = (props) => {
    return (<Avatar src={process.env.PUBLIC_URL.concat("/assets/icon/user/group.png")}/>);
};

const UAvatar = (props) => {
    return (
        <Badge dot status={states.get(props.session.states)} offset={[29, -2]}>
            <Avatar src={process.env.PUBLIC_URL.concat("/assets/icon/user/").concat('spider.png')}/>
        </Badge>
    );
};

const UserAvatar = observer((props) => {
    const members=props.session.memberIds.length;
    return (members>2?<GAvatar/> : <UAvatar session={props.session}/>);
});

export default UserAvatar;