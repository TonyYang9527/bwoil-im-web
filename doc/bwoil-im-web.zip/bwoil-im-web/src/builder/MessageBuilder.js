import DateUtils from '../tools/DateUtils' ;
import Constant from '../tools/Constant' ;
import UserStore from '../stores/UserStore' ;
let  message ={
      id: 0,
      type: '',
      msgDetail: '',
      messageStatus: '',
      conversationId : '' ,
      sendTimeStr:'',
      random : '' ,
      senderId:'',
      sender :{
            senderId : '' ,
            senderName: '',
            senderIcon: ''
     }
};

const MessageBuilder = {
    transform:(convsId,type,msgDetail,random) => {
      let now = DateUtils.currentTimeStamp() ;
        message.id='' ;
        message.type=type ;
        message.msgDetail =msgDetail ;
        message.messageStatus ='' ;
        message.conversationId =convsId ;
        message.sendTime =now ;
        message.sendTimeStr =DateUtils.currentHHMM(now) ;
        message.random=random ;
        message.senderId = UserStore.state.userId;
        message.sender = {
            senderId : UserStore.state.userId ,
            senderName: 'Tony',
            senderIcon: Constant.ICONPATH.concat('spider.png')
        } ;
       return  message;
   }

} ;
export default MessageBuilder ;