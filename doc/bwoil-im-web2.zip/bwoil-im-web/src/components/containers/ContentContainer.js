import React from 'react';
import {observer} from 'mobx-react';
import Members from '../chat-box/members/Members';
import Header from '../chat-box/header/Header';
import Typing from '../chat-box/typing/Typing';
import Messages from '../chat-box/messages/Messages';
import sessionStore from '../../stores/SessionStore';
import messageStore from '../../stores/MessageStore';
import conversationStore from '../../stores/ConversationStore';
import addContactStore from '../../stores/AddContactStore';
import partnerStore from '../../stores/PartnerStore';
import './Content.less';

const ContentContainer = observer(() => {

    if (!sessionStore.state.selected) {
        return <div className='content'/>;
    }
    let name = sessionStore.state.selected.name ? sessionStore.state.selected.name : '';
    let count = sessionStore.state.selected.users ? '(' + sessionStore.state.selected.users.length + ')' : '';
    return (
        <div className='content'>
            <Members users={sessionStore.state.selected.users} visable={partnerStore.state.modalShow}/>
            <Header name={name} count={count}
                    modalShow={partnerStore.state.modalShow}
                    upDown={partnerStore.actions.upDown}
                    openModal={() => addContactStore.actions.openModal(sessionStore.state.selected.id)}/>
            <Messages messages={messageStore.data.messages.values()}
                      setScrollbar={conversationStore.actions.setScrollbar}/>
            <Typing/>
        </div>
    );
});

export default ContentContainer;
