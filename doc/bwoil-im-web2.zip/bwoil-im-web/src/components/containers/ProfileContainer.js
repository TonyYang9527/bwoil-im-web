import React from 'react';
import {observer} from 'mobx-react';
import {Icon} from 'antd';
import Profile from '../profile/Profile';
import profileStore from '../../stores/ProfileStore';
import AddContact from '../add-contact/AddContact';
import addContactStore from '../../stores/AddContactStore';
import './Profile.less';

const ProfileContainer = observer((props) => {
        return (
            <div className='profile-container'>
                <div className='profile-container-control'>
                    <Icon type='minus'/>
                    <Icon type='close'/>
                </div>
                <Profile cargo={profileStore.state.cargo} vessel={profileStore.state.vessel}/>
                <AddContact state={addContactStore.state} actions={addContactStore.actions}/>
            </div>
        );
    }
);

export default ProfileContainer;
