import React from 'react';
import {observer} from 'mobx-react';
import {Dropdown, Menu} from 'antd';
import './DropMenu.less';

const DropMenu = observer((props) => {


    const onClick = (e) => {
        props.dropdown(e.key, props.session);
        e.domEvent.stopPropagation();
    };

    const menu = (
        <Menu className='session-tools' onClick={onClick}>
            <Menu.Item key="1">Delete chat</Menu.Item>
            <Menu.Item key="2">Rename group</Menu.Item>
            <Menu.Item key="3">Exit group</Menu.Item>
        </Menu>
    );

    return (
        <Dropdown overlay={menu}>
            <img alt="" src={require('../../../assets/more.svg')}/>
        </Dropdown>
    );

});
export default DropMenu;