import React from 'react';
import {observer} from 'mobx-react';
import {Card} from 'antd';
import UserAvatar from './avatar/UserAvatar';
import Panels from './panel/Panels';
import CombineView from './combine/CombineView';
import BwoilScrollbars from "../scrollbars/Scrollbars" ;
import './index.less';

const ConvsnItem = observer((props) => {

    //const style ={width: 250};
    const avatar =(<UserAvatar session={props.session} />) ;
    const panels = (<Panels session={props.session}/>);
    const combineView = <CombineView session={props.session} dropdown={props.actions.dropdown}
                                         onOk={props.actions.onOk} onCancel={props.actions.onCancel}/>;
    const onClick = (e) => {
        console.log("Conversation  onClick") ;
        props.actions.select(props.session.id);
        e.stopPropagation();
    };
    
    return (
        <Card  className={props.session.className}  onClick={onClick}>
            <Card.Meta avatar={avatar} title={panels} description={combineView}  />
        </Card>
    );
});


const ConvsnList = observer((props) => {
    if(props.conversations.size <=0){
        return null ;
    }
    const convsns= props.conversations.map((elem, index) =><ConvsnItem session={elem}  actions={props.actions}  key={index}/>) ;
    return (
        <div style={{ width: 250, height: 572 }} > 
        <BwoilScrollbars>
          {convsns} 
       </BwoilScrollbars>
        </div>
      );
});

export {ConvsnItem , ConvsnList} ;