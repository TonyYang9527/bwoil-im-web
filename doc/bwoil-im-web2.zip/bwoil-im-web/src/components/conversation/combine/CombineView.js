import React from 'react';
import {observer} from 'mobx-react';
import DropMenu from '../dropmenu/DropMenu';
import Confirm from '../confirm/Confirm';

const CombineView = observer((props) => {

    return (
        <div>
            <span>{props.session.message}</span>
            <DropMenu session={props.session} dropdown={props.dropdown}/>
            <Confirm session={props.session} onOk={props.onOk} onCancel={props.onCancel}/>
        </div>
    );
});

export default CombineView;