import React from 'react';
import {observer} from 'mobx-react';
import {Badge} from 'antd';

const Panels = observer((props) => {
    return (
        <div>
            <span>
                <span> {props.session.name}</span>
                <Badge count={props.session.unread} overflowCount={99} />
            </span>
            <span>{props.session.time}</span>
        </div>
    );
});

export default Panels;