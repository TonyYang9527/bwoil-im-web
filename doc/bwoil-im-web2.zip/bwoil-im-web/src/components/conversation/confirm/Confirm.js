import React from 'react';
import {observer} from 'mobx-react';
import {Modal, Input} from 'antd';
import './Confirm.less';

const okText_map = new Map([["1", "Delete"], ["2", "Rename"], ["3", "Exit"]]);
const title_map = new Map([["1", "Delete chat"], ["2", "Rename group"], ["3", "Exit group"]]);

const Children = observer((props) => {
    const onChange = (e) => {
        props.session.name = e.target.value;
        e.stopPropagation();
    };
    return (<Input value={props.session.name} onChange={onChange}/>);
});

const Confirm = observer((props) => {
    const id = props.session.id;
    const opt = props.session.opt;

    const onCancel = (e) => {
        props.onCancel(opt, id);
        e.stopPropagation();
    };

    const onOk = (e) => {
        props.onOk(opt, id);
        e.stopPropagation();
    };

    return (
        <Modal className='modify-tool' closable={false} cancelText='Cancel' destroyOnClose={true} maskClosable={false}
               onCancel={onCancel} onOk={onOk} title={title_map.get(opt)} okText={okText_map.get(opt)}
               visible={props.session.modalVisible}>
            {opt !== "2" ? null : <Children session={props.session}/>}
        </Modal>
    );
});

export default Confirm;