import React from 'react';
import {observer} from 'mobx-react';
import {Icon, Input, Button, Avatar, Checkbox} from 'antd';
import BwoilScrollbars from '../../components/scrollbars/Scrollbars';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import './AddContact.less';


const Title = (props) => {
    return (
        <div className='add-contact-title'>
            <span>Contact List</span>
            <Icon type='close' style={{color: '#212121', fontSize: 16}} onClick={props.close}/>
        </div>
    );
};

const Search = (props) => {
    let {filter, onChange, clear} = props;
    const prefix = <Icon type="search" style={{color: 'rgba(0,0,0,.25)', fontSize: 16}}/>;
    const suffix = filter ? <Icon type="close-circle" style={{color: 'rgba(0,0,0,.25)', fontSize: 16}}
                                  onClick={clear}/> : null;
    return (
        <div className='add-contact-search'>
            <Input prefix={prefix} suffix={suffix} value={filter}
                   onChange={onChange}
                   placeholder="Search contact…"/>
        </div>
    );
};

const AddContactItem = (props) => {
    let {contact, onCheckChange} = props;
    return (
        <div className={contact.className}>
            <div>
                    <span className='add-contact-icon'>
                        <Avatar src={contact.icon}/>
                        <span className='add-contact-point'/>
                    </span>
                <span className='add-contact-name'>{contact.contactName}</span>
            </div>
            <Checkbox checked={contact.contain || contact.exists} disabled={contact.contain}
                      onChange={e => onCheckChange(e.target.checked, contact)}/>
        </div>
    );
};

const AddItemList = (props) => {
    let {contacts, onCheckChange} = props;
    return (
        <BwoilScrollbars style={{width: '100%', flexGrow: 1}}>
            {contacts.map((elem, index) => {
                return <AddContactItem contact={elem} onCheckChange={onCheckChange} key={index}/>
            })}
        </BwoilScrollbars>
    );
};

const ConfirmButton = (props) => {
    let {addContact} = props;
    return (
        <div className='add-contact-foot'>
            <Button type='primary' onClick={addContact}>Add to chat</Button>
        </div>
    );
};

const AddContact = observer((props) => {
        let {state, actions} = props;
        return (
            <ReactCSSTransitionGroup
                transitionName="add-contact-animate"
                transitionEnterTimeout={500}
                transitionLeaveTimeout={300}>
                {state.visible ?
                    <div className='add-contact'>
                        <Title close={actions.closeModal}/>
                        <Search filter={state.filter} onChange={actions.changeFilter} clear={actions.clearFilter}/>
                        <AddItemList contacts={state.contacts} onCheckChange={actions.preAdding}/>
                        <ConfirmButton addContact={actions.addContact}/>
                    </div> : null}
            </ReactCSSTransitionGroup>
        );
    }
);

export default AddContact;