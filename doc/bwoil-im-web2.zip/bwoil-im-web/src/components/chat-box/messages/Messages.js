import React from 'react';
import {observer} from "mobx-react";
import BwoilScrollbars from "../../scrollbars/Scrollbars";
import Message from '../../message/index' ;
import './messages.less';

const Messages = observer((props) => {
    return (
        <div style={{width: '100%', height: '77%'}}>
            <BwoilScrollbars setScrollbar={props.setScrollbar}>
                {props.messages.map((item, index) => <Message message={item} key={index}/>)}
            </BwoilScrollbars>
        </div>
    );
});
export default Messages;