import React from 'react';
import {observer} from 'mobx-react';
import {Icon} from 'antd';
import './header.less';

const UpDown = (props) => {

    const upDown = (e) => {
        props.upDown();
        e.stopPropagation();
    };
    const icon = props.modalShow ? 'up' : 'down';
    const style = {marginLeft: 6};
    return (<Icon type={icon} style={style} onClick={upDown}/>);
};

const Invite = (props) => {

    const onInvite = (e) => {
        props.openModal();
        e.stopPropagation();
    };
    return (<Icon type='user-add' onClick={onInvite}/>);
};

const BoxHeader = observer((props) => {
    return (
        <div className='content-title'>
            <span>
                <span>{props.name}</span>
                <span>{props.count}</span>
                <UpDown modalShow={props.modalShow} upDown={props.upDown}/>
            </span>
            <Invite openModal={props.openModal}/>
        </div>
    );
});

export default BoxHeader;