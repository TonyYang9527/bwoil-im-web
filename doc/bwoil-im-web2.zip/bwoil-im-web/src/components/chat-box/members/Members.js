import React from 'react';
import {observer} from 'mobx-react';
import {Avatar} from 'antd';
import BwoilScrollbars from '../../../components/scrollbars/Scrollbars';
import MemberUtil from '../../../utils/MemberUtil';
import './members.less';

const MemberItem = (props) => {
    let {member} = props;
    return (
        <span className='online'>
            <Avatar src={member.icon}/>
            <span>{member.name}</span>
        </span>
    );
};


const BoxMembers = observer((props) => {
    let {users, visable} = props;
    if (!visable) {
        return null;
    }
    let members = MemberUtil.arrangeMembers(users);
    let height = MemberUtil.getHeight(users);

    return (
        <div className='partner'>
            <BwoilScrollbars style={{width: '100%', height: height}}>
                {
                    members.map((elem, index) => {
                        return (
                            <div className='partner-row' key={index}>
                                {elem.map((el, idx) => <MemberItem member={el} key={idx}/>)}
                            </div>
                        )
                    })
                }
            </BwoilScrollbars>
        </div>
    );
});

export default BoxMembers;