import React from 'react';
import {observer} from "mobx-react";
import { Icon} from 'antd';

const MsgStaus = observer((props) => {
    if (props.status === 'sent') {
        return (<Icon type='check' style={{ fontSize: 9, color: '#B0B0B0' }} />);
    } else if (props.status === 'allread') {
        return (<Icon type='check' style={{ fontSize: 9, color: '#B0B0B0' }} />);
    } else if (props.status === 'read') {
        return (<Icon type='check' style={{ fontSize: 9, color: '#5CB0FF' }} />);
    } else {
        return null;
    }
});
export default MsgStaus;