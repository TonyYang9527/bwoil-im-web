import React from 'react';
import {observer} from "mobx-react";
import {UserMsagBody} from './body/MsgBody' ;
import {UserImgAvatar} from './avatar/UserAvatar' ;
import './index.less';

/****
 * TEXT :
 *   right: bubble bubble_primary right
 *   left: bubble bubble_default left
 * IMAGE :
 *   right: bubble bubble_primary_image right
 *   left:  bubble bubble_default_image left
 * ******/
const Message = observer((props) => {
    let msgOwner = props.message.fromUser ? 'message  me' : 'message  you';
    let bubble = "";
    if (props.message.type === "text") {
        bubble = props.message.fromUser ? 'bubble bubble_primary right' : 'bubble bubble_default left';
    } else if (props.message.type === "image") {
        bubble = props.message.fromUser ? 'bubble bubble_primary_image right' : 'bubble bubble_default_image left';
    } else if (props.message.type === "pdf" || props.message.type === "doc"
        || props.message.type === "txt" || props.message.type === "xls"
        || props.message.type === "ppt") {
        bubble = props.message.fromUser ? 'bubble bubble_primary_attach right' : 'bubble bubble_default_attach left';
    } else {
        bubble = props.message.fromUser ? 'bubble bubble_primary right' : 'bubble bubble_default left';
    }
    return (
        <div className={msgOwner}>
            <UserImgAvatar message={props.message}/>
            <UserMsagBody message={props.message} className={bubble}/>
        </div>
    );
});

export default Message;