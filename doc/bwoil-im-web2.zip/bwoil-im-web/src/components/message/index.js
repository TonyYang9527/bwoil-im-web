import React from 'react';
import {observer} from "mobx-react";
import BwoilScrollbars from "../scrollbars/Scrollbars";
import Message from '../message/message/Message';
import './index.less';

const MessagesList = observer((props) => {
    return (
        <div style={{ width: 480, height: 476 }}> 
            <BwoilScrollbars>
                {props.messages.map((elem, index) => <Message message={elem} key={index} />)}  
            </BwoilScrollbars>
        </div>
    );
});
export default MessagesList;