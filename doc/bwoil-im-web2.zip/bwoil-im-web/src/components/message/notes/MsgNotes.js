import React from 'react';
import { observer } from "mobx-react";
import MsgStaus from '../status/MsgStaus';

const MsgNotes = observer((props) => {
    return (
        <div className="msgstatus">
          <span className='message-prompt'>
            <span className='message-time'>{props.message.sendTime}</span>
            <MsgStaus status={props.message.messageStatus} />
          </span>
        </div> 
    );
});
export default MsgNotes;
