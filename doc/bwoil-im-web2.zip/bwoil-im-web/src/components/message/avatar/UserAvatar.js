import React from 'react';
import { observer } from "mobx-react";
import {Avatar } from 'antd';
import randomColor from 'random-color';


const UserAvatar = (props) => {
    return (<Avatar shape="square" size="small" icon="team" style={{ backgroundColor: randomColor().hexString() }} />);
};

const UserImgAvatar = observer((props) => {
    let deficon = process.env.PUBLIC_URL.concat("/assets/icon/user/ironman.png") ;
    return (<img className="avatar" src={props.message.avatar? props.message.avatar:deficon} alt=""/>);
});

export {UserAvatar ,UserImgAvatar} ;