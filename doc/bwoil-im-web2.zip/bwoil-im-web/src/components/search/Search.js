import React from 'react';
import {observer} from 'mobx-react';
import {Icon, Input} from 'antd';
import './Search.less';

const Suffix = observer((props)=>{
    if(!props.filter)
       return null; 
    const onClick = (e) => {
        props.clear();
    };   
    return (<Icon type="close-circle" onClick={onClick}/>);
  });

const SearchInput = observer((props) => { 
    const style = { fontSize: 14, background: '#EFEFEF', borderRadius: 4 };
    const prefix = (<Icon type="search" />);
    const suffix = (<Suffix filter={props.filter} clear={props.clear} />);
    const onChange = (e) => {
        console.log("onChange: ", e.target.value) ;
        var value = e.target.value;
        props.change(value);
    };
    return (
        <Input size="large" placeholder='Search contact…'
            style={style} value={props.filter} prefix={prefix} suffix={suffix}
            onChange={onChange} />
        );
});

const Search = observer((props) => {
        return (
            <div className='search'>
                <SearchInput filter={props.filter} change={props.change} clear={props.clear} />
            </div>
        );
});
export default Search;