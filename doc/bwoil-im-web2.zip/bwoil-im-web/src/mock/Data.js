export const messages = [
    {
        id: '10002',
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/antman.png"),
        type: "text",
        msgDetail: "I am customer service  , Glad to chat with  you. ",
        messageStatus: "sent",
        sendTime: "02:49",
        sender: 'King',
        fromUser: false
    },
    {
        id: '10003',
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/atom.png"),
        type: "image",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "allread",
        sendTime: "02:49",
        sender: 'Tony',
        fromUser: true
    },
    {
        id: '10004',
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/batmen.png"),
        type: "text",
        msgDetail: "Hi Jim, I have some issues ..",
        messageStatus: "read",
        sendTime: "02:49",
        sender: 'Jack',
        fromUser: false
    },
    {
        id: '10005',
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/captain.png"),
        type: "text",
        msgDetail: "What is  issues?",
        expiry: "03:49",
        messageStatus: "read",
        sendTime: "02:49",
        sender: 'Mike',
        fromUser: true
    },
    {
        id: '10006',
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/flash.png"),
        type: "text",
        msgDetail: "After install the bmo-rest-client, you need to create a apiConfig file in your project under service folder All your API used in your project will be set in apiConfig",
        messageStatus: "sent",
        sendTime: "02:49",
        sender: 'Mike',
        fromUser: true
    },
    {
        id: '10007',
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/greenman.png"),
        type: "image",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "allread",
        sendTime: "02:49",
        sender: 'williness',
        fromUser: false
    },
    {
        id: '10008',
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/hulk.png"),
        type: "pdf",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "allread",
        sendTime: "02:49",
        sender: 'williness',
        fromUser: false
    },
    {
        id: '10009',
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/ironman.png"),
        type: "doc",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "allread",
        sendTime: "02:49",
        sender: 'williness',
        fromUser: true
    },

    {
        id: '10010',
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/spider.png"),
        type: "txt",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "allread",
        sendTime: "02:49",
        sender: 'williness',
        fromUser: false
    },

    {
        id: '10011',
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/superman.png"),
        type: "xls",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "allread",
        sendTime: "02:49",
        sender: 'williness',
        fromUser: true
    },
    {
        id: '10012',
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/superman.png"),
        type: "ppt",
        msgDetail: "https://tctechcrunch2011.files.wordpress.com/2018/02/gettyimages-913011976.jpg",
        messageStatus: "allread",
        sendTime: "02:49",
        sender: 'williness',
        fromUser: false
    }
];

export const profiles = {
    vessel: 'BRIGHTOIL GLORY',
    sector: 'Oil Tanker',
    openDate: '01/01/2018',
    openPorts: 'Singapore,China, Indonesia,India',
    cargoVessel: 'PIG IRON,5000MT',
    laycanDate: '01-05 Jan 2018',
    voyage: 'Singapore>Shanghai',
    loadRate: '1500/1500',
    addressComission: '3.75%',
    freight: 'SGD:15/MTS'
};

export const cargo = {
    cargo: 'PIG IRON,5000MT',
    laycanDate: '01-05 Jan 2018',
    voyage: 'Singapore>Shanghai',
    loadRate: '1500/1500',
    addressComission: '3.75%',
    freight: 'SGD:15/MTS'
};

export const vessel = {
    vessel: 'BRIGHTOIL GLORY',
    sector: 'Oil Tanker',
    openDate: '01/01/2018',
    openPorts: 'Singapore,China, Indonesia,India'
};


export const step = {
    current: 1,
    status: 'finish'
};

export const sessions = [
    {
        id: 101,
        name: 'Jim King,Yang Sun,Qiaomin Jin',
        status: "success",  // 0:offline 1:online
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        unread: 10,
        time: "02:49",
        message: "I miss you dear,call me please. I leave message  to  you.",
        partners: [200, 201, 202, 203, 204, 205, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115]
    },
    {
        id: 102,
        name: 'Jake Li',
        status: "default", // 0:offline 1:online
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        unread: 10,
        time: "02:49",
        message: "Please  comfirm our contact .",
        partners: [200, 202, 203]
    },

    {
        id: 103,
        name: 'Tony.yang',
        status: "error", // 0:offline 1:online
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        unread: 10,
        time: "02:49",
        message: "Please  comfirm our contact .",
        partners: [202, 203]
    }
];

export const contacts = [
    {
        id: 200,
        name: "Jim King",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 201,
        name: "Yang Sun",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "default"
    },
    {
        id: 202,
        name: "QiaoMin Jin",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 203,
        name: "Jake Li",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "default"
    },
    {
        id: 204,
        name: "Standly McNair",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 205,
        name: "Charles Smith",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 106,
        name: "Kelli Ortiz",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 107,
        name: "Tony Yang",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "success"
    },
    {
        id: 108,
        name: "Lebron James",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "success"
    },
    {
        id: 109,
        name: "Embid",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "success"
    },
    {
        id: 110,
        name: "Durant",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 111,
        name: "Howard",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 112,
        name: "Wade",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 113,
        name: "Anthony",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 114,
        name: "George",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "error"
    },
    {
        id: 115,
        name: "WhiteSide",
        image: process.env.PUBLIC_URL.concat("/assets/icon/user/master.jpg"),
        status: "success"
    }
];