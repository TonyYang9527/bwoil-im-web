import {action, observable} from "mobx";
import contactStore from './ContactStore';
import sessionStore from './SessionStore';

const state = observable({
    visible: false,
    id: 0,
    filter: '',
    preAdd: observable.map(),
    get contacts() {
        let that = this;
        return that.filter ? contactStore.data.contacts.values()
                .map((elem) => {
                    elem.contain = sessionStore.state.selected.users.some((el) => el.id === elem.contactId);
                    elem.exists = this.preAdd.values().some((el) => el.contactId === elem.contactId);
                    elem.className = elem.contain ? 'add-contact-item add-contact-item-focused' : 'add-contact-item';
                    return elem;
                })
                .filter((elem) => elem.contactName.toLowerCase().indexOf(that.filter.toLowerCase()) !== -1)
            : [];
    }
});

const actions = {
    openModal: action((id) => {
        state.visible = true;
        state.id = id;
        let {users} = sessionStore.state.sessions.get(id);
        console.log(users);
    }),
    closeModal: action(() => {
        state.id = 0;
        state.filter = '';
        state.preAdd.clear();
        state.visible = false;
    }),
    preAdding: action((checked, contact) => {
        if (checked) {
            state.preAdd.set(contact.contactId, contact);
        } else {
            state.preAdd.delete(contact.contactId);
        }
    }),
    changeFilter: action(e => {
        state.filter = e.target.value;
    }),
    clearFilter: action(() => {
        state.filter = '';
    }),
    addContact: action(() => {
        sessionStore.actions.addContact(state.id, state.preAdd.values());
    })
};

export default {state, actions};