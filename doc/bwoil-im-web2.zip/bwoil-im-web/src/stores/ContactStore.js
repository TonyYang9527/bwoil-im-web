import {observable, action, when} from 'mobx';
import ContactUtil from '../utils/ContactUtil';
import userStore from '../stores/UserStore';


const data = observable({
    contacts: observable.map()
});

const actions = {
    init: action(() => {
        let {userId} = userStore.state;
        let params = {userId: userId};
        console.log(params);
        ContactUtil.getContactList(params).then((contacts) => {
            contacts.forEach(elem => {
                data.contacts.set(elem.contactId, elem);
            });
        });
    }),
    add: action((contact) => {
        if (!data.contacts.has(contact.contactId)) {
            data.contacts.set(contact.contactId, contact);
        }
    }),
    rename: action((id, name) => {
        if (data.contacts.has(id)) {
            data.contacts.get(id).name = name;
        }
    }),
    delete: action((id) => {
        if (data.contacts.has(id)) {
            data.contacts.delete(id);
        }
    })
};

when(
    () => !data.contacts.size,
    () => {
        actions.init();
    }
);

export default {data, actions};