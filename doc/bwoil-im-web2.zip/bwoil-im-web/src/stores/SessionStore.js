import {observable, action, autorun, when} from 'mobx';
import globalStore from './GlobalStore';
import messageStore from './MessageStore';
import conversationStore from './ConversationStore';
import profileStore from './ProfileStore';
import addContactStore from './AddContactStore';
import partnerStore from './PartnerStore';
import userStore from '../stores/UserStore';
import SessionUtil from '../utils/SessionUtil';

const state = observable({
    sessions: observable.map(),
    selected: {},
    copy: {}
});

const actions = {
    init: action(() => {
        /**TODO: please call init api**/
        let {userId} = userStore.state;
        let params = {userId: userId};
        SessionUtil.getSessionList(params).then((sessions) => {
            sessions.forEach((item) => {
                state.sessions.set(item.id, item);
            });
        });
    }),

    select: action((id) => {
        if (id !== state.selected.id) {
            if (state.sessions.has(id)) {
                state.selected = state.sessions.get(id);
                state.selected.unread = 0;
                actions.changeStyle(id);

                /**TODO: please call other api**/
                messageStore.actions.init(id);
                conversationStore.actions.init(id);
                profileStore.actions.init(id);
                addContactStore.actions.closeModal();
            }
        }
    }),

    add: action((contact) => {
        /**TODO: please call add api**/
        let {userId, name} = userStore.state;
        let userIds = [userId, contact.contactId];
        let names = `${name},${contact.contactName}`;
        let params = {userId: userId, name: names, userIds: userIds};
        SessionUtil.getNewSession(params).then((session) => {
            state.sessions.set(session.id, session);
            actions.changeStyle(session.id);
            state.selected = state.sessions.get(session.id);
            globalStore.actions.restoreTab();
            addContactStore.actions.closeModal();
        });
    }),

    onOk: action((opt, covsId) => {
        if (opt === "1") { //delete conversation
            let {userId} = userStore.state;
            let params = {userId: userId, covsIds: [covsId]};
            SessionUtil.deleteSession(params).then((result) => {
                if (result) {
                    state.sessions.delete(covsId);
                }
            });
            /**TODO: please call delete api**/
        } else if (opt === "2") { //rename conversation
            let userId = userStore.state.userId;
            let name = state.sessions.get(covsId).name;
            let conversation = {userId: userId, covsId: covsId, name: name};
            SessionUtil.renameSession(conversation).then((res) => {
                    if (res.result) {
                        state.sessions.get(res.id).name = res.name;
                        state.sessions.get(covsId).modalVisible = false
                    }
                }
            );
        } else if (opt === "3") { //exit  conversation
            let userId = userStore.state.userId;
            let conversation = {userId: userId, covsId: covsId};
            SessionUtil.exitSession(conversation).then((res) => {
                if (res.result) {
                    state.sessions.delete(covsId);
                }
            });
        }
    }),

    onCancel: action((opt, id) => {
        if (opt === "2") {
            state.sessions.get(id).name = state.copy.name;
            state.sessions.get(id).modalVisible = false;
        } else if (opt === "1" || opt === "3") {
            state.sessions.get(id).modalVisible = false;
        } else {
            //  do  nothing
        }
    }),

    dropdown: action((key, session) => {
        session.modalVisible = true;
        session.opt = key;
        state.copy = {id: session.id, opt: key, name: session.name};
    }),

    addContact: action((id, preAdd) => {
        /**TODO: please call invite  api**/
        let {userId} = userStore.state;
        let {name, users} = state.sessions.get(id);
        let userIds = users.map((elem => elem.id)).concat(preAdd.map(elem => elem.contactId));
        let params = {userId: userId, covsId: id, name: name, userIds: userIds};
        SessionUtil.addContact(params).then((session) => {
            let {id} = session;
            console.log('add后的session', session);
            state.sessions.set(id, session);
            state.selected = state.sessions.get(id);
            addContactStore.actions.closeModal();
        });
    }),

    changeStyle: action((id) => {
        state.sessions.forEach((value, key, map) => {
            if (key === id) {
                value.className = 'conversation conversation-focused';
            } else {
                value.className = 'conversation';
            }
        });
    }),
};

when(
    () => !state.sessions.size,
    () => {
        actions.init();
    }
);

autorun(() => {
    if (state.selected.partners) {
        partnerStore.actions.closeModal();
    }
});

export default {state, actions};