import {observable, action, autorun} from 'mobx';
import {RestClient} from "bmo-rest-client";
import userStore from "./UserStore";
import conversationStore from "./ConversationStore";
import apiConfig from "../services/apiConfig";
import WebSocketConfig from '../services/webSocketConfig';
import MessageUtil from "../utils/MessageUtil";
import {messages} from '../mock/Data';


const data = observable({
    id: 0,
    messages: observable.map()
});

const actions = {
    init: action((id) => {
        if (data.id !== id) {
            data.id = id;
            data.messages.clear();
            /**mock*/
            messages.forEach((item) => {
                if (item.type === 'image') {
                    item.visible = false;
                }
                data.messages.set(item.id, item);
            });
            /**mock*/
            let {userId} = userStore.state;
            let temp = {userId: userId, covsId: id};
            RestClient.call(apiConfig.messageList, null, temp)
                .then(res => {
                    let {data: messages} = res.data;
                    MessageUtil.arrangeByTime(messages).forEach(elem => {
                        elem.sendTime = MessageUtil.getTime(elem.sendTime);
                        elem.type = MessageUtil.getType(elem.type);
                        elem.messageStatus = MessageUtil.getStatus(elem.messageStatus);
                        elem.fromUser = (elem.senderId === userId);
                        data.messages.set(elem.id, elem);
                    });
                });
        }
    }),

    addMessage: action((msg, convsId) => {
        let {userId, name} = userStore.state;
        let time = Date.now();
        let msgId = `${userId}${convsId}${time}`;
        data.messages.set(msgId, MessageUtil.createLocalMessage(msg, userId, msgId, name));
        WebSocketConfig.send(MessageUtil.createSendingMessage(msg, userId, convsId, msgId));
    }),
     addNewMessage: action((message) => {
        data.messages.set(message.id, message);
    }),

};

autorun(() => {
    if (data.messages.size) {
        setTimeout(conversationStore.actions.scrollToBottom, 0);
    }
});

export default {data, actions};