import {observable, action} from 'mobx';
import {RestClient} from 'bmo-rest-client';
import apiConfig from '../services/apiConfig';


const state = observable({
      userId: '987654321123456789',
      name: 'tony.yang',
      email : '',
});

const actions = {
    setUserId: action((id) => {
        state.userId = id;
    }),
    login:action((email,password) => {
        let token =null ;
        RestClient.call(apiConfig.login, null,{email:email ,password:password}).then(res =>{
            if(res.status === 200){
               token=res.data.access_token;
            }   
        });
       return token  ;
    })
};

export default {state, actions};