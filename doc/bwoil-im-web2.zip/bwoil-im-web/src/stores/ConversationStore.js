import {observable, action, autorun, when} from 'mobx';
import messageStore from './MessageStore';
import WebSocketConfig from '../services/webSocketConfig';


const data = observable({
    id: 0,
    scrollbar: null,
    textArea: null,
    text: '',
});

const actions = {
    init: action((id) => {
        if (data.id !== id) {
            data.id = `${id}`;
            data.text = '';
        }
    }),
    onFocus: action((e) => {
        if (!data.textArea) {
            data.textArea = e.target;
        }
    }),
    onChange: action((e) => {
        data.text = e.target.value;
    }),
    sendMessage: action((e) => {
        e.preventDefault();
        if (data.text) {
            messageStore.actions.addMessage(data.text, data.id);
            data.text = '';
        }
    }),
    setScrollbar: action((scrollbar) => {
        data.scrollbar = scrollbar;
    }),

    scrollToBottom: action(() => {
        if (data.scrollbar) {
            data.scrollbar.scrollToBottom();
        }
    })
};

when(
    () => !data.textArea,
    () => {
        WebSocketConfig.getToken();
    }
);


autorun(() => {
    if (data.text) {
        if (data.textArea.scrollHeight > data.textArea.clientHeight) {
            if (!data.textArea.classList.contains('with-scrollbar')) {
                data.textArea.classList.add('with-scrollbar');
            }
        } else {
            if (data.textArea.classList.contains('with-scrollbar')) {
                data.textArea.classList.remove('with-scrollbar');
            }
        }
    } else {
        if (data.textArea) {
            data.textArea.focus();
        }
    }
});

export default {data, actions};