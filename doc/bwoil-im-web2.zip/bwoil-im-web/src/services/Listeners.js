import WebSocketClient from 'bmo-websocket-client';
import messageStore from '../stores/MessageStore' ;

const Listeners = { };
const openListener = () => {};
const errorListener = ({message}) => {
    console.log('CLIENT ERROR:',message);
};
const connectedListener = ({status, message}) => {
    /***1:control send button***/
    /***2:send user state change***/
    console.log('CLIENT CONNECTED:[' + status + ']');
};
const disconnectedListener = () => {
    console.log('CLIENT DISCONNECTED');
};
const connectionErrorListener = ({status, message}) => {
    console.log('CLIENT CONNECTED FAILED:' + status ,message);
};
const connectionUnacceptableListener = ({status, message}) => {
    console.log('CLIENT UNACCEPTABLE:',status ,message );
};
const eventSendingFailListener = ({status, message, eventId}) => {
    console.log('CLIENT SENDED FAILED:',status, message ,'EVENT:' + eventId );
};

const eventSendingSuccessListener = ({eventId}) => {
 
    console.log('CLIENT SENDED SUCCESS:',eventId);
};

 /**customize event**/
 const  eventAddMessageListener = ({eventName, eventData}) => {
    console.log('ADD MESSAGE:',eventName , JSON.stringify(eventData));
   let message = {
        id: eventData.messages.id,
        avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/flash.png"),
        type: 'text',
        message: eventData.messages.msgDetail,
        status: 'sent',
        time: '09:12',
        sender: 'John',
        fromUser: false
    };
    messageStore.actions.addNewMessage(message) ;
};
/******conversation********/
const eventAddConversationListener = ({eventName, eventData}) => {
    console.log(' ADD CONVERSATION: ',eventName , JSON.stringify(eventData));
};

const eventDeleteConversationListener = ({eventName, eventData}) => {
    console.log('DELETE CONVERSATION :', eventName ,JSON.stringify(eventData));
};

/******contact********/
const eventAddContactListener = ({eventName, eventData}) => {
    console.log('ADD  CONTACT :', eventName ,JSON.stringify(eventData));
};

const eventDeleteContactListener = ({eventName, eventData}) => {
    console.log('DELETE  CONTACT :', eventName ,JSON.stringify(eventData));
};
/******contact********/
const eventUserStateListener = ({eventName, eventData}) => {
    console.log('USER STATE:', eventName ,JSON.stringify(eventData));
};

Listeners[WebSocketClient.listenerType.OPEN] = openListener;
Listeners[WebSocketClient.listenerType.ERROR] = errorListener;
Listeners[WebSocketClient.listenerType.CONNECTED] = connectedListener;
Listeners[WebSocketClient.listenerType.DISCONNECTED] = disconnectedListener;
Listeners[WebSocketClient.listenerType.CONNECTION_ERROR] = connectionErrorListener;
Listeners[WebSocketClient.listenerType.CONNECTION_UNACCEPTABLE] = connectionUnacceptableListener;
Listeners[WebSocketClient.listenerType.SENDING_FAILURE] = eventSendingFailListener;
Listeners[WebSocketClient.listenerType.SENDING_SUCCESS] = eventSendingSuccessListener;
/**message event**/
Listeners['/im/message/add'] = eventAddMessageListener;
/**conversation event**/
Listeners['/im/conversation/add'] = eventAddConversationListener;
Listeners['/im/conversation/delete'] = eventDeleteConversationListener;
/**contact event**/
Listeners['/im/contact/add'] = eventAddContactListener;
Listeners['/im/contact/delete'] = eventDeleteContactListener;
/**contact event**/
Listeners['/im/user/state'] = eventUserStateListener;

export default Listeners;