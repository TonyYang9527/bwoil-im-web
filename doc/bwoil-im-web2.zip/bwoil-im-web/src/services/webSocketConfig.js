import WebSocketClient from 'bmo-websocket-client';
import apiConfig from './apiConfig';
import Listeners from './Listeners';
import Configuration from './Configuration';
import {RestClient} from 'bmo-rest-client';

const WebSocketConfig = {
     wsclient: null,
     getRetryInterval:(count) => { 
          console.log("getRetryInterval running") ;  
          return 1000 * count; 
        },

     initWSClient :(token) =>{
          let config = Configuration.init(token,Listeners) ;
          WebSocketClient.create(config).then(
                (res)=>{WebSocketConfig.wsclient = res; WebSocketConfig.connect();},     
                (err)=>{console.error('  WEBSOCKET CLIENT INIT FAILED :', err);}) ;
          console.log('WEBSOCKET CLIENT INIT SUCCEED!');
       },

        connect:() =>{
           WebSocketConfig.wsclient.connect().then( 
              (res) =>{ console.log('CONNECTED SUCCEED'); } , 
              (err) =>{  console.error('CONNECTED FAILED :', err);}    
           ); 
    },
    send:(message)=> {
        if (WebSocketConfig.wsclient) {
            WebSocketConfig.wsclient.send(message);
        }
    },

    getToken:()=>{
        let user = {"email": "tony.yang@bwoil.com","password": "123456" };
        RestClient.call(apiConfig.login, null, user).then(res =>{
                if(res.status === 200){
                 let {access_token: token} = res.data;
                  WebSocketConfig.initWSClient(token);
                }
            });
    }
};
export default WebSocketConfig;