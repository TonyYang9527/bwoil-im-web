import {Endpoint, Request} from 'bmo-rest-client';

const apiConfig = {
    /*****login API********/
    login: Endpoint(Request.POST, "/sso/u/login"),
    /*****conversation API********/
    covsList: Endpoint(Request.POST, "/im/conversation/list"),
    covsAdd: Endpoint(Request.POST, "/im/conversation/add"),
    covsUpdate: Endpoint(Request.POST, "/im/conversation/update"),
    covsDelete: Endpoint(Request.POST, "/im/conversation/delete"),
    covsPagination: Endpoint(Request.POST, "/im/conversation/pagination"),
    /*****contact API********/
    contactList: Endpoint(Request.POST, "/im/contact/list"),
    contactAdd: Endpoint(Request.POST, "/im/contact/add"),
    contactUpdate: Endpoint(Request.POST, "/im/contact/update"),
    contactDelete: Endpoint(Request.POST, "/im/contact/delete"),
    contactPagination: Endpoint(Request.POST, "/im/contact/pagination"),
    /*****message API********/
    messageList: Endpoint(Request.POST, "/im/message/list"),
};

export default apiConfig;