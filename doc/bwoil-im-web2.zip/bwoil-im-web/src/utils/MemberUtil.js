const MemberUtil = {
    arrangeMembers: function (members) {
        let temp = [];
        let length = Math.ceil(members.length / 2);
        if (length > 0) {
            if (members.length % 2 === 0) {
                for (let i = 0; i < length; i++) {
                    temp.push([members[i * 2], members[i * 2 + 1]]);
                }
            } else {
                for (let i = 0; i < length; i++) {
                    if (i !== length - 1) {
                        temp.push([members[i * 2], members[i * 2 + 1]]);
                    } else {
                        temp.push([members[i * 2]]);
                    }

                }
            }
        }
        return temp;
    },

    getHeight: function (members) {
        let length = Math.ceil(members.length / 2);
        return length > 5 ? 256 : 16 + 48 * length;
    }
};

export default MemberUtil;