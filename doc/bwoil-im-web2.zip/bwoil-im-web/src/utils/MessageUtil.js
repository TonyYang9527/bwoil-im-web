const months = {
    '0': 'Jan', '1': 'Feb', '2': 'Mar', '3': 'Apr', '4': 'May', '5': 'Jun',
    '6': 'Jul', '7': 'Aug', '8': 'Sep', '9': 'Oct', '10': 'Nov', '11': 'Dec'
};

const status_list = {
    '1': 'sent',
    '2': 'read',
    '3': 'allread'
};

const types = {'1': 'text'};


const MessageUtil = {

    getType: function (type) {
        return types[type];
    },

    getStatus: function (status) {
        if (status) {
            return status_list[status];
        }
        return 'sent';
    },

    getTime: function (sendTime) {
        if (sendTime) {
            let date = new Date(sendTime);
            let now = new Date();
            if (date.toDateString() === now.toDateString()) {
                let hour = date.getHours() > 9 ? date.getHours() : `0${date.getHours()}`;
                let minute = date.getMinutes() > 9 ? date.getMinutes() : `0${date.getMinutes()}`;
                return `${hour}:${minute}`;
            } else {
                return `${months[date.getMonth()]} ${date.getDate()}`;
            }
        } else {
            return '';
        }
    },

    arrangeByTime: function (arr) {
        let len = arr.length;
        for (let i = 0; i < len; i++) {
            for (let j = 0; j < len - 1 - i; j++) {
                if (arr[j].sendTime > arr[j + 1].sendTime) {
                    let temp = arr[j + 1];
                    arr[j + 1] = arr[j];
                    arr[j] = temp;
                }
            }
        }
        return arr;
    },

    createSendingMessage: function (msg, userId, convsId, msgId) {
        return [{
            'id': msgId,
            'uri': 'im/message/add',
            'body': {
                "msgItems": [
                    {
                        "conversationId": convsId,
                        "msgDetail": msg,
                        "senderId": userId,
                        "type": 1
                    }
                ]
            }
        }];
    },

    createLocalMessage: function (msg, userId, msgId, name) {
        let that = this;
        return {
            id: msgId,
            avatar: process.env.PUBLIC_URL.concat("/assets/icon/user/flash.png"),
            type: 'text',
            msgDetail: msg,
            messageStatus: 'sent',
            sendTime: that.getTime(Date.now()),
            senderId: userId,
            fromUser: true
        }
    }
};

export default MessageUtil;

