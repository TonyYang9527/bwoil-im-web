import {RestClient} from "bmo-rest-client";
import apiConfig from "../services/apiConfig";

const ContactUtil = {
    getContactList: function (param) {
        return RestClient.call(apiConfig.contactList, null, param)
            .then(res => {
                console.log(res);
                let {result, data = []} = res.data;
                if (result) {
                    return data;
                }
                return [];
            });
    }
};

export default ContactUtil;