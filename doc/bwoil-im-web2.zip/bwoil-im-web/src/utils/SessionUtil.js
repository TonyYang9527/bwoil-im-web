import {RestClient} from 'bmo-rest-client';
import apiConfig from '../services/apiConfig';


const months = {
    '0': 'Jan', '1': 'Feb', '2': 'Mar', '3': 'Apr', '4': 'May', '5': 'Jun',
    '6': 'Jul', '7': 'Aug', '8': 'Sep', '9': 'Oct', '10': 'Nov', '11': 'Dec'
};

const statusList = {'0': 'default', '1': 'success', '2': 'error'};


const SessionUtil = {

    getStatus: function (state) {
        return statusList[state] ? statusList[state] : statusList[0];
    },

    getLocalTime: function (time) {
        if (time) {
            let date = new Date(time);
            let now = new Date();
            if (date.toDateString() === now.toDateString()) {
                let hour = date.getHours() > 9 ? date.getHours() : `0${date.getHours()}`;
                let minute = date.getMinutes() > 9 ? date.getMinutes() : `0${date.getMinutes()}`;
                return `${hour}:${minute}`;
            }
            return `${date.getDate()} ${months[date.getMonth()]}`;
        } else {
            return '';
        }
    },

    getSessionList: function (params) {
        let that = this;
        return RestClient.call(apiConfig.covsList, null, params)
            .then(res => {
                let {result, data = []} = res.data;
                if (result) {
                    return data.map((item) => {
                        item.states = that.getStatus(item.states);
                        item.updateTime = that.getLocalTime(item.updateTime);
                        item.className = "conversation";
                        item.modalVisible = false;
                        return item;
                    });
                }
                return [];
            });
    },

    getNewSession: function (params) {
        let that = this;
        return RestClient.call(apiConfig.covsAdd, null, params)
            .then(res => {
                let {data} = res.data;
                data.states = that.getStatus(data.states);
                data.updateTime = that.getLocalTime(data.updateTime);
                data.className = "conversation";
                data.modalVisible = false;
                return data;
            });
    },

    deleteSession: function (params) {
        return RestClient.call(apiConfig.covsDelete, null, params)
            .then(res => {
                let {result = false} = res.data;
                return result;
            });
    },

    renameSession: function (params) {
        return RestClient.call(apiConfig.covsUpdate, null, params)
            .then(res => {
                let {result = false, data = {}} = res.data;
                if (result) {
                    return {result: result, id: data.id, name: data.name};
                }
                return {result: result};
            });
    },

    exitSession: function (params) {
        return RestClient.call(apiConfig.covsUpdate, null, params)
            .then(res => {
                console.log(res);
                let {result = false, data = {}} = res.data;
                if (result) {
                    return {result: result, id: data.id};
                }
                return {result: result};
            });
    },

    addContact: function (params) {
        let that = this;
        return RestClient.call(apiConfig.covsUpdate, null, params)
            .then(res => {
                let {data} = res.data;
                data.states = that.getStatus(data.states);
                data.updateTime = that.getLocalTime(data.updateTime);
                data.className = "conversation conversation-focused";
                data.modalVisible = false;
                return data;
            });
    }
};

export default SessionUtil;