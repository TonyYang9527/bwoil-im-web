/**
 * Check Is image or not
 * @author Tony.yang
 **/

const RegExpUtils = { 

     isImage : (str) => {
        const strRegex = "(.jpg|.png|.gif|.jpeg)$";
        const regExp = new RegExp(strRegex);
        //console.log(str + " : " + regExp.test(str.toLowerCase()));
        return regExp.test(str.toLowerCase());
    },

     isMicroOffice : (str) => {
        const strRegex = "(.pdf|.doc|.txt|.xls|.ppt)$";
        const regExp = new RegExp(strRegex);
        //console.log(str + " : " + regExp.test(str.toLowerCase()));
        return regExp.test(str.toLowerCase());
    },

} ;

export default RegExpUtils ;